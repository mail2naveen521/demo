# Configuration Drift Detector
## WebSphere ND 8.5.5 + HCL Portal 9.5 on RHEL 8

A self-contained toolkit that snapshots WebSphere + HCL Portal configuration,
compares the live state against a trusted baseline, and emails a diff report
whenever drift is detected.

## What it monitors

**WebSphere Application Server ND 8.5.5**
- `wp_profile/config/cells/<cell>/**` — server.xml, security.xml,
  **resources.xml** (this is where the Portal `WP ConfigService`,
  `WP PUMA`, `WP CP Configuration Service` etc. resource environment
  providers live — most "Portal config" set via the WAS console lands here)
- `wp_profile/properties/**` — soap.client.props, ssl.client.props,
  sas.client.props, wsadmin.properties

**HCL Portal 9.5**
- `wp_profile/ConfigEngine/properties/wkplc.properties` — the master config
  file Portal admins edit
- `wp_profile/PortalServer/config/**` — service property overrides
  (PortalConfigService.properties, NavigatorService.properties, etc.)
- `wp_profile/PortalServer/shared/app/config/**` — shared app config
- `PortalServer/theme/**` — theme.html, theme.json, skins
- **Optional**: full logical config via `xmlaccess.sh -type export` (captures
  pages, portlet definitions, ACLs — things that don't live as flat files)

## How it works

1. **Baseline capture** (`capture-baseline.sh`) walks the watch directories,
   computes a SHA-256 of each file after scrubbing volatile noise (`xmi:id`
   values, save-time stamps, `.lastModified` epochs), and stores both the
   hash manifest and a copy of every file so real diffs can be produced.
2. **Drift check** (`check-drift.sh`) repeats the snapshot, compares hashes
   against the baseline, classifies every change as added / removed /
   modified, and writes an HTML report plus a unified-diff text file.
3. **Email alert** (`send-alert.sh` + `send-smtp.py`) ships the report.
   Plain-text part has a truncated preview; HTML body has per-file diffs
   with syntax highlighting; both the diff and HTML are attached. Mail
   goes out only when drift is detected (configurable).

## Install on RHEL 8

```bash
# 1. Verify the host is ready
sudo cp -r drift-detector /opt/
sudo chmod +x /opt/drift-detector/bin/*.sh /opt/drift-detector/bin/*.py
sudo /opt/drift-detector/bin/preflight.sh

# 2. Install any optional tools the preflight flagged
sudo dnf install -y s-nail            # mailx fallback
sudo dnf install -y epel-release
sudo dnf install -y inotify-tools     # only if using real-time watcher
sudo dnf install -y cronie            # if using cron schedule

# 3. Set ownership to the user that owns wp_profile (usually 'wasadmin')
sudo chown -R wasadmin:wasadmin /opt/drift-detector

# 4. Edit config — check these specific lines
sudo -u wasadmin vi /opt/drift-detector/config/drift-detector.conf
#    WAS_PROFILE_NAME — wp_profile (standalone), or dmgr_profile (cluster)
#    WAS_CELL_NAME    — match your cell
#    PORTAL_HOME      — usually /opt/IBM/WebSphere/PortalServer
#    MAIL_TO, MAIL_SMTP_HOST, MAIL_FROM

# 5. (Optional) protect the portal admin password for xmlaccess exports
sudo mkdir -p /etc/drift-detector
echo 'YourPortalAdminPassword' | sudo tee /etc/drift-detector/portal.pass >/dev/null
sudo chmod 600 /etc/drift-detector/portal.pass
sudo chown wasadmin:wasadmin /etc/drift-detector/portal.pass

# 6. Re-run preflight — should now show READY
sudo -u wasadmin /opt/drift-detector/bin/preflight.sh

# 7. Capture the trusted baseline (run AFTER a known-good config state)
sudo -u wasadmin /opt/drift-detector/bin/capture-baseline.sh

# 8. Schedule it — pick ONE
# Option A — cron every 5 min
sudo -u wasadmin /opt/drift-detector/bin/install-cron.sh
# Option B — systemd timer
sudo cp /opt/drift-detector/systemd/*.service /etc/systemd/system/
sudo cp /opt/drift-detector/systemd/*.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now drift-detector.timer
# Option C — real-time inotify watcher
sudo systemctl enable --now drift-detector-watch.service
```

## Standalone vs. cluster — which profile to monitor

Portal 9.5 deployments come in two shapes; pick the right `WAS_PROFILE_NAME`:

| Topology | Profile to monitor | Where to run the detector |
|---|---|---|
| Standalone Portal | `wp_profile` | The portal host |
| Cluster (Dmgr + nodes) | `dmgr_profile` | The Deployment Manager host |
| Plain WAS ND only (no Portal) | `AppSrv01` or `Dmgr01` | Same as above |

**Why this matters:** In a cluster, the Dmgr is the source of truth and
pushes config to each node on sync. If you monitor a node profile,
**every legitimate config push will alert as drift**. Always monitor
the Dmgr profile in a cluster — that's where config actually changes.

## Daily operations

| Task | Command |
|---|---|
| Verify host setup | `bin/preflight.sh` |
| Run a one-off check | `bin/check-drift.sh` |
| Re-baseline after an approved change | `bin/capture-baseline.sh` |
| View latest report | `ls -t reports/drift-report-*.html \| head -1` |
| Tail run log | `tail -f logs/drift-detector.log` |
| Test email pipeline (force send) | set `MAIL_ON_DRIFT_ONLY=false`, run check |

After **any** legitimate config change (`wsadmin` script, admin console edit,
xmlaccess import, ConfigEngine task, fix-pack), re-run `capture-baseline.sh`
so the new state becomes the trusted one. Otherwise you'll get noisy alerts.

## Reducing false positives

WebSphere 8.5.5 rewrites `xmi:id` values on many config saves and after
server restarts. Portal 9.5 stamps `.lastModified` epochs in service
properties on every save. The `config/scrub-patterns.txt` file lists regexes
(extended-regex syntax — `sed -E`) that are stripped *before* hashing so
these don't trigger drift. Pre-configured patterns:

- `xmi:id="..."` — WAS regenerated identifiers
- Java Properties timestamp headers (`#Sun Jan 01 12:00:00 UTC 2024`)
- Generated UUIDs
- `# Generated by ConfigWizard` / `# Generated by HCL Portal ConfigEngine`
- `.lastModified=<epoch>` — Portal service property timestamps
- `cacheTimestamp=` / `syncTimestamp=` — WCM and JCR markers
- `<!-- Plug-in Configuration generated on ... -->` — plugin-cfg.xml

Tune for your environment. Common additions:

```
# Build numbers
buildVersion="[0-9.]+"
# Generated session keys
sessionToken=[A-Za-z0-9+/=]+
```

If a particular file is fundamentally noisy (logs, caches), exclude it via
`EXCLUDE_PATTERNS` in `drift-detector.conf`.

## Mail transport options

The sender tries, in order:

1. **Python SMTP** (`send-smtp.py`) — Python 3.6+ stdlib; works without a
   local MTA. Set `MAIL_SMTP_HOST`, `MAIL_SMTP_PORT`, optionally
   `MAIL_SMTP_USER` and `MAIL_SMTP_PASS_FILE`, and `MAIL_USE_TLS=true` for
   STARTTLS or port 465.
2. **mailx** (`s-nail` package on RHEL 8) — for hosts with a local MTA.

For Microsoft 365 / Gmail relays you generally want `MAIL_USE_TLS=true` and
either port 587 (STARTTLS) or 465 (implicit TLS), with an app password in
`MAIL_SMTP_PASS_FILE`.

## SELinux

RHEL 8 typically runs SELinux in Enforcing mode. If a cron- or
systemd-spawned `check-drift.sh` can read your WAS config when run by hand
but fails under cron, check `/var/log/audit/audit.log` for `AVC denied`
messages. Two common fixes:

```bash
# Label the detector scripts as executable system binaries
sudo chcon -t bin_t /opt/drift-detector/bin/*.sh

# Or allow the cron domain to read user content
sudo setsebool -P cron_can_relabel 1
```

## Exit codes (for monitoring integration)

| Code | Meaning |
|---|---|
| 0 | No drift |
| 1 | Drift detected |
| 2 | Error (no baseline, missing dirs, etc.) |

Wire this into Nagios/Zabbix/Datadog for a second alerting path.

## File layout

```
drift-detector/
├── bin/
│   ├── preflight.sh           # NEW — verify host before install
│   ├── capture-baseline.sh    # Take a trusted snapshot
│   ├── check-drift.sh         # Compare current vs baseline
│   ├── send-alert.sh          # Email dispatcher (shell front-end)
│   ├── send-smtp.py           # Python SMTP back-end
│   ├── watch-realtime.sh      # Optional inotify watcher
│   ├── install-cron.sh        # Cron installer
│   └── lib-common.sh          # Shared functions
├── config/
│   ├── drift-detector.conf              # Defaults: WAS 8.5.5 + Portal 9.5
│   ├── drift-detector.conf.generic-example  # Generic fallback
│   └── scrub-patterns.txt     # Volatile-line regexes (sed -E syntax)
├── baselines/
│   ├── baseline.snapshot      # Symlink to active manifest
│   ├── baseline-<TS>.snapshot
│   ├── current-<TS>.snapshot
│   └── snapshots/
│       ├── baseline/          # File-content archive for diffs
│       └── current-<TS>/
├── reports/
│   ├── drift-report-<TS>.html
│   └── drift-diff-<TS>.txt
├── logs/
└── systemd/
    └── drift-detector.units
```

## Security notes

- Run as the OS user that owns `wp_profile` (typically `wasadmin`) — it
  needs read access to every config file. Don't run as root.
- Protect `${PORTAL_ADMIN_PASS_FILE}` and `${MAIL_SMTP_PASS_FILE}` with mode
  600.
- The diff archives under `baselines/snapshots/` contain copies of your
  config (including any secrets stored in `*.properties` files). Protect
  the whole `drift-detector/` tree the same way you'd protect the live
  profile. Consider mounting `baselines/` on an encrypted filesystem if
  your `server.xml` references encoded passwords.

## Troubleshooting

**"No baseline found"** — Run `capture-baseline.sh` once before scheduling
checks.

**Constant drift alerts after a server restart** — WebSphere rewrote
`xmi:id`s or Portal stamped new `.lastModified` epochs. Either add a
matching regex to `scrub-patterns.txt` (remember it's `sed -E` syntax),
exclude the noisy file, or re-baseline.

**xmlaccess export silently skipped** — `PORTAL_XMLACCESS_SCRIPT` path is
wrong, the password file is unreadable, or Portal isn't running. Check
`logs/drift-detector.log`.

**Mail not arriving** — Set `MAIL_ON_DRIFT_ONLY=false` and run a check to
force a send, then check `logs/drift-detector.log` and your SMTP relay logs.

**Cron job runs by hand but not on schedule (RHEL 8)** — Check `crond` is
enabled (`systemctl status crond`) and look for SELinux AVC denials in
`/var/log/audit/audit.log`.

**Many files flagged "modified" right after a fix-pack** — Expected:
applying a CF rewrites many config files. Treat the fix-pack as an
approved change and re-baseline immediately after.
