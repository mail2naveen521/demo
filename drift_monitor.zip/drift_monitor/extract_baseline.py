"""
WebSphere Configuration Baseline Extractor
Uses wsadmin Jython scripting to extract full DMGR configuration
Run via: wsadmin.sh -lang jython -f extract_baseline.py
"""

import os
import sys
import time
import hashlib
import json

# ─────────────────────────────────────────────
# CONFIG  – edit these before first run
# ─────────────────────────────────────────────
BASELINE_DIR   = "/opt/drift-monitor/baseline"
SNAPSHOT_DIR   = "/opt/drift-monitor/snapshots"
LOG_FILE       = "/opt/drift-monitor/logs/drift.log"
CELL_NAME      = AdminControl.getCell()          # auto-detected from DMGR

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = "[%s] %s" % (ts, msg)
    print line
    try:
        fh = open(LOG_FILE, "a")
        fh.write(line + "\n")
        fh.close()
    except:
        pass


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def sha256_str(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def write_json(path, data):
    fh = open(path, "w")
    fh.write(json.dumps(data, indent=2, sort_keys=True))
    fh.close()


def read_json(path):
    fh = open(path, "r")
    data = json.loads(fh.read())
    fh.close()
    return data

# ─────────────────────────────────────────────
# EXTRACTION FUNCTIONS (wsadmin AdminConfig API)
# ─────────────────────────────────────────────

def get_cell_config():
    """Extract cell-level configuration"""
    cell_id = AdminConfig.getid("/Cell:%s/" % CELL_NAME)
    attrs    = AdminConfig.show(cell_id).strip()
    return {"id": cell_id, "attributes": attrs}


def get_nodes():
    """Extract all node configurations"""
    nodes = {}
    for node_id in AdminConfig.list("Node").splitlines():
        node_id = node_id.strip()
        if not node_id:
            continue
        name  = AdminConfig.showAttribute(node_id, "name")
        attrs = AdminConfig.show(node_id).strip()
        nodes[name] = {"id": node_id, "attributes": attrs}
    return nodes


def get_servers():
    """Extract all server configurations"""
    servers = {}
    for srv_id in AdminConfig.list("Server").splitlines():
        srv_id = srv_id.strip()
        if not srv_id:
            continue
        name  = AdminConfig.showAttribute(srv_id, "name")
        attrs = AdminConfig.show(srv_id).strip()

        # JVM settings
        jvm_ids = AdminConfig.list("JavaVirtualMachine", srv_id).splitlines()
        jvm_cfg = {}
        for jvm_id in jvm_ids:
            jvm_id = jvm_id.strip()
            if jvm_id:
                jvm_cfg = AdminConfig.show(jvm_id).strip()

        # Thread pools
        thread_pools = {}
        for tp_id in AdminConfig.list("ThreadPool", srv_id).splitlines():
            tp_id = tp_id.strip()
            if tp_id:
                tp_name = AdminConfig.showAttribute(tp_id, "name")
                thread_pools[tp_name] = AdminConfig.show(tp_id).strip()

        servers[name] = {
            "id"          : srv_id,
            "attributes"  : attrs,
            "jvm"         : jvm_cfg,
            "thread_pools": thread_pools,
        }
    return servers


def get_datasources():
    """Extract all JDBC datasource configurations"""
    ds_map = {}
    for ds_id in AdminConfig.list("DataSource").splitlines():
        ds_id = ds_id.strip()
        if not ds_id:
            continue
        name = AdminConfig.showAttribute(ds_id, "name")
        attrs = AdminConfig.show(ds_id).strip()

        # Connection pool
        cp_ids = AdminConfig.list("ConnectionPool", ds_id).splitlines()
        cp_cfg = {}
        for cp_id in cp_ids:
            cp_id = cp_id.strip()
            if cp_id:
                cp_cfg = AdminConfig.show(cp_id).strip()

        ds_map[name] = {
            "id"              : ds_id,
            "attributes"      : attrs,
            "connection_pool" : cp_cfg,
        }
    return ds_map


def get_virtual_hosts():
    """Extract virtual host configurations"""
    vh_map = {}
    for vh_id in AdminConfig.list("VirtualHost").splitlines():
        vh_id = vh_id.strip()
        if not vh_id:
            continue
        name  = AdminConfig.showAttribute(vh_id, "name")
        attrs = AdminConfig.show(vh_id).strip()
        vh_map[name] = {"id": vh_id, "attributes": attrs}
    return vh_map


def get_security_config():
    """Extract global security configuration"""
    sec_ids = AdminConfig.list("Security").splitlines()
    if sec_ids:
        sec_id = sec_ids[0].strip()
        return AdminConfig.show(sec_id).strip()
    return ""


def get_clusters():
    """Extract server cluster configurations"""
    cluster_map = {}
    for cl_id in AdminConfig.list("ServerCluster").splitlines():
        cl_id = cl_id.strip()
        if not cl_id:
            continue
        name  = AdminConfig.showAttribute(cl_id, "name")
        attrs = AdminConfig.show(cl_id).strip()

        members = {}
        for mb_id in AdminConfig.list("ClusterMember", cl_id).splitlines():
            mb_id = mb_id.strip()
            if mb_id:
                mb_name = AdminConfig.showAttribute(mb_id, "memberName")
                members[mb_name] = AdminConfig.show(mb_id).strip()

        cluster_map[name] = {
            "id"        : cl_id,
            "attributes": attrs,
            "members"   : members,
        }
    return cluster_map


def get_resource_env_providers():
    """Extract Resource Environment Providers"""
    rep_map = {}
    for rep_id in AdminConfig.list("ResourceEnvironmentProvider").splitlines():
        rep_id = rep_id.strip()
        if not rep_id:
            continue
        name  = AdminConfig.showAttribute(rep_id, "name")
        attrs = AdminConfig.show(rep_id).strip()
        rep_map[name] = {"id": rep_id, "attributes": attrs}
    return rep_map


def get_jms_resources():
    """Extract JMS connection factories and queues"""
    result = {"connection_factories": {}, "queues": {}, "topics": {}}

    for cf_id in AdminConfig.list("MQQueueConnectionFactory").splitlines():
        cf_id = cf_id.strip()
        if not cf_id:
            continue
        name = AdminConfig.showAttribute(cf_id, "name")
        result["connection_factories"][name] = AdminConfig.show(cf_id).strip()

    for q_id in AdminConfig.list("MQQueue").splitlines():
        q_id = q_id.strip()
        if not q_id:
            continue
        name = AdminConfig.showAttribute(q_id, "name")
        result["queues"][name] = AdminConfig.show(q_id).strip()

    for t_id in AdminConfig.list("MQTopic").splitlines():
        t_id = t_id.strip()
        if not t_id:
            continue
        name = AdminConfig.showAttribute(t_id, "name")
        result["topics"][name] = AdminConfig.show(t_id).strip()

    return result


def get_ssl_config():
    """Extract SSL configurations"""
    ssl_map = {}
    for ssl_id in AdminConfig.list("SSLConfig").splitlines():
        ssl_id = ssl_id.strip()
        if not ssl_id:
            continue
        name  = AdminConfig.showAttribute(ssl_id, "alias")
        attrs = AdminConfig.show(ssl_id).strip()
        ssl_map[name] = {"id": ssl_id, "attributes": attrs}
    return ssl_map


def get_libraries():
    """Extract shared library configurations"""
    lib_map = {}
    for lib_id in AdminConfig.list("Library").splitlines():
        lib_id = lib_id.strip()
        if not lib_id:
            continue
        name  = AdminConfig.showAttribute(lib_id, "name")
        attrs = AdminConfig.show(lib_id).strip()
        lib_map[name] = {"id": lib_id, "attributes": attrs}
    return lib_map


# ─────────────────────────────────────────────
# MAIN SNAPSHOT BUILDER
# ─────────────────────────────────────────────

def build_snapshot():
    log("Starting full configuration snapshot for cell: %s" % CELL_NAME)

    snapshot = {
        "metadata": {
            "cell"      : CELL_NAME,
            "timestamp" : time.strftime("%Y-%m-%dT%H:%M:%S"),
            "epoch"     : int(time.time()),
            "dmgr_host" : AdminControl.getAttribute(
                            AdminControl.queryNames("type=DeploymentManager,*"), "hostName"),
            "was_version": AdminControl.getAttribute(
                            AdminControl.queryNames("type=Server,j2eeType=J2EEServer,name=dmgr,*"),
                            "platformVersion"),
        },
        "sections": {
            "cell"                    : get_cell_config(),
            "nodes"                   : get_nodes(),
            "servers"                 : get_servers(),
            "clusters"                : get_clusters(),
            "datasources"             : get_datasources(),
            "virtual_hosts"           : get_virtual_hosts(),
            "security"                : get_security_config(),
            "ssl"                     : get_ssl_config(),
            "jms"                     : get_jms_resources(),
            "resource_env_providers"  : get_resource_env_providers(),
            "libraries"               : get_libraries(),
        }
    }

    # Compute per-section hashes
    hashes = {}
    for section, content in snapshot["sections"].items():
        serialised      = json.dumps(content, sort_keys=True)
        hashes[section] = sha256_str(serialised)

    snapshot["hashes"]         = hashes
    snapshot["composite_hash"] = sha256_str(json.dumps(hashes, sort_keys=True))

    log("Snapshot composite hash: %s" % snapshot["composite_hash"])
    return snapshot


# ─────────────────────────────────────────────
# ENTRY POINTS
# ─────────────────────────────────────────────

def save_baseline():
    """Save a new baseline (call once at setup time)"""
    ensure_dir(BASELINE_DIR)
    ensure_dir(os.path.dirname(LOG_FILE))

    snap = build_snapshot()
    baseline_path = os.path.join(BASELINE_DIR, "baseline.json")
    write_json(baseline_path, snap)
    log("Baseline saved to: %s" % baseline_path)
    return baseline_path


def save_snapshot():
    """Save a live snapshot for comparison"""
    ensure_dir(SNAPSHOT_DIR)
    ensure_dir(os.path.dirname(LOG_FILE))

    snap = build_snapshot()
    ts   = time.strftime("%Y%m%d_%H%M%S")
    snap_path = os.path.join(SNAPSHOT_DIR, "snapshot_%s.json" % ts)
    write_json(snap_path, snap)
    log("Snapshot saved to: %s" % snap_path)
    return snap_path


# ── script mode ──────────────────────────────
if __name__ == "__main__" or True:
    mode = "baseline"
    if len(sys.argv) > 1:
        mode = sys.argv[1]

    if mode == "baseline":
        save_baseline()
    elif mode == "snapshot":
        save_snapshot()
    else:
        log("Unknown mode: %s  (use 'baseline' or 'snapshot')" % mode)
        sys.exit(1)
