#!/bin/bash
# =============================================================================
#  WebSphere Drift Monitor – Scheduler Wrapper
#  Invoked every 60 minutes by cron (or IBM Job Manager).
#
#  CRONTAB ENTRY (add via: crontab -e as wasadmin user):
#  0 * * * * /opt/drift-monitor/bin/run_drift_check.sh >> /opt/drift-monitor/logs/cron.log 2>&1
# =============================================================================

set -euo pipefail

# ── CONFIGURATION ─────────────────────────────────────────────────────────────
WAS_HOME="${WAS_HOME:-/opt/IBM/WebSphere/AppServer}"
DMGR_PROFILE="${DMGR_PROFILE:-/opt/IBM/WebSphere/AppServer/profiles/Dmgr01}"
SCRIPTS_DIR="${SCRIPTS_DIR:-/opt/drift-monitor/scripts}"
LOCK_FILE="/opt/drift-monitor/run.lock"
LOG_DIR="/opt/drift-monitor/logs"
WSADMIN_USER="${WSADMIN_USER:-wsadmin}"
WSADMIN_PASS_FILE="${WSADMIN_PASS_FILE:-/opt/drift-monitor/conf/.wsadmin.pass}"
DMGR_HOST="${DMGR_HOST:-localhost}"
DMGR_SOAP_PORT="${DMGR_SOAP_PORT:-8879}"

mkdir -p "${LOG_DIR}"

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
echo "[${TIMESTAMP}] Starting drift check run..."

# ── LOCK (prevent overlapping runs) ──────────────────────────────────────────
if [ -f "${LOCK_FILE}" ]; then
    LOCK_PID=$(cat "${LOCK_FILE}")
    if kill -0 "${LOCK_PID}" 2>/dev/null; then
        echo "[${TIMESTAMP}] Previous run (PID ${LOCK_PID}) still active. Skipping."
        exit 0
    else
        echo "[${TIMESTAMP}] Stale lock removed."
        rm -f "${LOCK_FILE}"
    fi
fi
echo $$ > "${LOCK_FILE}"
trap "rm -f '${LOCK_FILE}'" EXIT

# ── ENVIRONMENT SETUP ─────────────────────────────────────────────────────────
export PATH="${WAS_HOME}/bin:${PATH}"
export JAVA_HOME="${WAS_HOME}/java/8.0"

# ── WSADMIN INVOCATION ────────────────────────────────────────────────────────
WSADMIN="${DMGR_PROFILE}/bin/wsadmin.sh"

if [ ! -x "${WSADMIN}" ]; then
    echo "ERROR: wsadmin not found at ${WSADMIN}"
    exit 1
fi

WSADMIN_OPTS=(
    -lang jython
    -host "${DMGR_HOST}"
    -port "${DMGR_SOAP_PORT}"
    -conntype SOAP
    -user "${WSADMIN_USER}"
    -f "${SCRIPTS_DIR}/detect_drift.py"
)

# Append password securely if file exists
if [ -f "${WSADMIN_PASS_FILE}" ]; then
    WSADMIN_OPTS+=(-password "$(cat "${WSADMIN_PASS_FILE}")")
else
    echo "WARN: Password file not found; relying on soap.client.props"
fi

RUN_LOG="${LOG_DIR}/drift_$(date '+%Y%m%d_%H%M%S').log"

"${WSADMIN}" "${WSADMIN_OPTS[@]}" 2>&1 | tee "${RUN_LOG}"
EXIT_CODE=${PIPESTATUS[0]}

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
if [ "${EXIT_CODE}" -eq 0 ]; then
    echo "[${TIMESTAMP}] Drift check completed successfully."
else
    echo "[${TIMESTAMP}] Drift check FAILED with exit code ${EXIT_CODE}."
fi

# ── ROTATE OLD RUN LOGS (keep 7 days) ────────────────────────────────────────
find "${LOG_DIR}" -name "drift_*.log" -mtime +7 -delete 2>/dev/null || true

exit "${EXIT_CODE}"
