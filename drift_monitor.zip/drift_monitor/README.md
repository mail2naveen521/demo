# WebSphere Configuration Drift Monitor

Automated configuration drift detection for IBM WebSphere Application Server ND,
using native **wsadmin / AdminConfig** scripting APIs — no third-party agents required.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    DMGR (Deployment Manager)                     │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  wsadmin (Jython) – AdminConfig / AdminControl APIs      │   │
│  │                                                          │   │
│  │  extract_baseline.py  ──► baseline/baseline.json         │   │
│  │  detect_drift.py      ──► snapshots/ + reports/          │   │
│  │  manage_drift.py      ──► operator utility               │   │
│  └──────────────────────────────────────────────────────────┘   │
│            ▲                          │                          │
│   cron / IBM Job Manager (60 min)     │ drift detected           │
│                                       ▼                          │
│                           SMTP → ops@yourcompany.com             │
└─────────────────────────────────────────────────────────────────┘
```

### What gets monitored

| Section | WAS API Used | Key Attributes Tracked |
|---|---|---|
| **Cell** | `AdminConfig.list("Cell")` | Cell properties, timeout settings |
| **Nodes** | `AdminConfig.list("Node")` | Node sync, hostname, platform |
| **Servers** | `AdminConfig.list("Server")` | All server settings per node |
| **JVM** | `AdminConfig.list("JavaVirtualMachine")` | Heap, JVM args, classpath |
| **Thread Pools** | `AdminConfig.list("ThreadPool")` | Min/max threads, timeout |
| **Clusters** | `AdminConfig.list("ServerCluster")` | Cluster members, weights |
| **DataSources** | `AdminConfig.list("DataSource")` | JNDI, URL, connection pool |
| **Virtual Hosts** | `AdminConfig.list("VirtualHost")` | Host aliases, ports |
| **Security** | `AdminConfig.list("Security")` | Global security, LTPA |
| **SSL** | `AdminConfig.list("SSLConfig")` | Ciphers, keystores, protocols |
| **JMS** | `AdminConfig.list("MQQueue*")` | MQ queues, topics, CFs |
| **Libraries** | `AdminConfig.list("Library")` | Shared library classpaths |
| **REPs** | `AdminConfig.list("ResourceEnvironmentProvider")` | JNDI resources |

---

## Directory Layout

```
/opt/drift-monitor/
├── bin/
│   ├── setup.sh              ← Run once to initialise
│   └── run_drift_check.sh    ← Cron entrypoint (every 60 min)
├── scripts/
│   ├── extract_baseline.py   ← Jython: capture config snapshot
│   ├── detect_drift.py       ← Jython: compare + alert
│   └── manage_drift.py       ← Jython: operator CLI
├── baseline/
│   ├── baseline.json         ← Golden baseline
│   └── archive/              ← Previous baselines
├── snapshots/                ← Hourly live snapshots (72 kept)
├── reports/                  ← Drift reports JSON (72 kept)
├── conf/
│   ├── .wsadmin.pass         ← chmod 600, wsadmin password
│   └── job_manager_schedule.xml ← IBM Job Manager alternative
└── logs/
    ├── drift.log             ← Append-only audit log
    └── cron.log              ← Cron stdout/stderr
```

---

## Prerequisites

- IBM WebSphere Application Server ND **8.5.5+** or **9.0.x**
- DMGR running and reachable via SOAP connector (default port 8879)
- `wasadmin` OS user with write access to `/opt/drift-monitor/`
- SMTP server reachable from DMGR host
- Python 2.7 (bundled with WAS Jython) — no pip installs needed

---

## Installation

### Step 1 – Deploy files

```bash
# As root or wasadmin
cp -r websphere-drift/  /opt/drift-monitor-src/
chmod +x /opt/drift-monitor-src/bin/*.sh
```

### Step 2 – Run interactive setup

```bash
cd /opt/drift-monitor-src
./bin/setup.sh
```

The setup wizard will:
1. Create `/opt/drift-monitor/` directory structure
2. Prompt for **internal SMTP relay hostname**, FROM address, and TO addresses only — no password or port needed
3. Prompt for wsadmin credentials (stored in `conf/.wsadmin.pass` with 600 permissions)
4. Connect to DMGR and capture the **initial baseline**
5. Install a cron job for hourly checks

### Step 3 – Verify

```bash
# Immediate test run
/opt/drift-monitor/bin/run_drift_check.sh

# Check status
/opt/IBM/WebSphere/AppServer/profiles/Dmgr01/bin/wsadmin.sh \
  -lang jython -f /opt/drift-monitor/scripts/manage_drift.py status
```

---

## Usage – Operator Commands

All commands run via wsadmin from the DMGR:

```bash
WSADMIN="$DMGR_PROFILE/bin/wsadmin.sh -lang jython -conntype SOAP"

# View latest check result
$WSADMIN -f /opt/drift-monitor/scripts/manage_drift.py status

# View last 20 drift check results
$WSADMIN -f /opt/drift-monitor/scripts/manage_drift.py history 20

# Update baseline after approved configuration change
$WSADMIN -f /opt/drift-monitor/scripts/manage_drift.py update-baseline

# Compare live config against a specific historical snapshot
$WSADMIN -f /opt/drift-monitor/scripts/manage_drift.py compare \
  /opt/drift-monitor/snapshots/snapshot_20240315_120000.json
```

---

## Drift Alert Email

When drift is detected you receive an email like:

```
Subject: [CRITICAL] WebSphere Config Drift Detected – MyCell – 2024-03-15 14:00:00

======================================================================
  WebSphere Configuration Drift Alert
======================================================================

Cell            : MyCell
Detection Time  : 2024-03-15T14:00:05
Severity        : *** CRITICAL ***
Total Changes   : 7
Critical Changes: 3

Baseline taken  : 2024-03-15T08:00:01
Live snapshot   : 2024-03-15T14:00:05

──────────────────────────────────────────────────────────────────────
SECTION SUMMARY
──────────────────────────────────────────────────────────────────────
✓  cell                            OK      (0 changes)
✓  clusters                        OK      (0 changes)
✗  datasources                     DRIFTED (2 changes)
✗  servers                         DRIFTED (4 changes)
✗  ssl                             DRIFTED (1 changes)

──────────────────────────────────────────────────────────────────────
DETAILED CHANGES
──────────────────────────────────────────────────────────────────────

[1] PATH        : datasources.MyDataSource.connection_pool.maxConnections
    TYPE        : MODIFIED
    BASELINE    : 50
    LIVE        : 100

[2] PATH        : servers.server1.jvm.maximumHeapSize
    TYPE        : MODIFIED
    BASELINE    : 1024
    LIVE        : 2048
...

ACTION REQUIRED
──────────────────────────────────────────────────────────────────────
1. Review changes above and verify if they are authorised.
2. If unauthorised, roll back via WAS admin console or wsadmin.
3. If authorised, update the baseline by running:
   wsadmin.sh -lang jython -f extract_baseline.py baseline
```

---

## Severity Classification

| Severity | Condition |
|---|---|
| **CRITICAL** | Changes in: security, SSL, JVM settings, datasources, clusters |
| **HIGH** | > 20 total attribute changes |
| **MEDIUM** | 6–20 total attribute changes |
| **LOW** | 1–5 total attribute changes |

---

## Ignored Attributes

These transient/metadata attributes are excluded from drift comparison to eliminate false positives:

```python
IGNORED_ATTRS = ["lastModified", "modifiedBy", "deploymentDescriptorVersion"]
```

Add more patterns to this list in `detect_drift.py` as needed.

---

## IBM Job Manager Alternative (for WAS ND environments)

If you prefer IBM Job Manager over cron:

```bash
# Import the pre-built schedule
wsadmin.sh -lang jython -c "
AdminTask.submitJob(['-jobXML', '/opt/drift-monitor/conf/job_manager_schedule.xml'])
"
```

Edit `conf/job_manager_schedule.xml` to set your DMGR hostname and credential alias first.

---

## Operational Runbook

### After a planned change – refresh baseline
```bash
# After making and validating your approved WAS config change:
wsadmin.sh -lang jython \
  -f /opt/drift-monitor/scripts/manage_drift.py update-baseline
```

### Roll back an unauthorised change
```bash
# The drift report shows the baseline (approved) values.
# Use wsadmin AdminConfig.modify() or the Admin Console to revert.
# Example – revert a JVM heap change on server1:
wsadmin.sh -lang jython -c "
jvm = AdminConfig.list('JavaVirtualMachine', 
       AdminConfig.getid('/Node:node1/Server:server1/'))
AdminConfig.modify(jvm, [['maximumHeapSize', '1024']])
AdminConfig.save()
"
```

### Disable monitoring temporarily
```bash
crontab -l | grep -v run_drift_check | crontab -
```

### Re-enable monitoring
```bash
( crontab -l; echo "0 * * * * /opt/drift-monitor/bin/run_drift_check.sh >> /opt/drift-monitor/logs/cron.log 2>&1" ) | crontab -
```

---

## Security Notes

- `conf/.wsadmin.pass` has mode **600** and is owned by `wasadmin`
- No WAS credentials appear in crontab (passed via file reference)
- **No SMTP credentials are stored anywhere** — email is sent via your internal corporate relay on port 25, which accepts unauthenticated connections from trusted internal hosts (standard in most enterprise networks)
- Ensure your mail relay is configured to allow relay from the DMGR server's IP (whitelist it in your relay's `mynetworks` or equivalent)
- All snapshot and report JSON files contain configuration data; restrict read access to `drift-monitor` directory
