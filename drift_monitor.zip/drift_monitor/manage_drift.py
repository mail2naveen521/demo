"""
WebSphere Drift Monitor – Report Viewer & Baseline Manager
Utility script for operators to view drift history and manage baselines.

Usage:
  wsadmin.sh -lang jython -f manage_drift.py [command]

Commands:
  status          – Show latest drift check result
  history [N]     – Show last N drift reports (default 10)
  update-baseline – Capture fresh baseline (use after approved changes)
  compare [file]  – Compare current live config against a specific snapshot
"""

import os
import sys
import json
import time
import glob

# ─────────────────────────────────────────────
MONITOR_HOME = "/opt/drift-monitor"
BASELINE_DIR = os.path.join(MONITOR_HOME, "baseline")
SNAPSHOT_DIR = os.path.join(MONITOR_HOME, "snapshots")
REPORT_DIR   = os.path.join(MONITOR_HOME, "reports")
SCRIPTS_DIR  = os.path.join(MONITOR_HOME, "scripts")

# ─────────────────────────────────────────────

def read_json(path):
    fh   = open(path, "r")
    data = json.loads(fh.read())
    fh.close()
    return data


def hr(char="─", width=70):
    print char * width


def print_status():
    """Show the latest drift report status"""
    reports = sorted(glob.glob(os.path.join(REPORT_DIR, "drift_report_*.json")))
    if not reports:
        print "No drift reports found. Has the monitor run yet?"
        return

    latest_path = reports[-1]
    report = read_json(latest_path)

    hr("=")
    print "  WebSphere Drift Monitor – Status"
    hr("=")
    print "Cell            : %s" % report.get("cell", "unknown")
    print "Last Check      : %s" % report.get("run_at", "unknown")
    print "Baseline From   : %s" % report.get("baseline_timestamp", "unknown")

    if report.get("drift_detected"):
        print "Status          : *** DRIFT DETECTED ***"
        print "Severity        : %s" % report.get("severity", "UNKNOWN")
        print "Total Changes   : %d" % report.get("total_changes", 0)
        print "Critical Changes: %d" % report.get("critical_change_count", 0)
        print ""
        hr()
        print "SECTION SUMMARY"
        hr()
        for sec, info in sorted(report.get("section_summary", {}).items()):
            icon = "✗" if info["status"] == "DRIFTED" else "✓"
            print "  %s  %-30s  %s (%d)" % (icon, sec, info["status"], info["change_count"])
        print ""
        print "Report file: %s" % latest_path
    else:
        print "Status          : CLEAN – No drift detected"
    hr("=")


def print_history(n=10):
    """Show history of last N drift checks"""
    reports = sorted(glob.glob(os.path.join(REPORT_DIR, "drift_report_*.json")))[-n:]

    hr("=")
    print "  Drift Check History (last %d)" % n
    hr("=")
    print "  %-22s  %-10s  %-8s  %s" % ("RUN_AT", "STATUS", "CHANGES", "SEVERITY")
    hr()

    for path in reversed(reports):
        try:
            r = read_json(path)
            status   = "DRIFTED" if r.get("drift_detected") else "CLEAN"
            changes  = r.get("total_changes", 0)
            severity = r.get("severity", "-") if r.get("drift_detected") else "-"
            print "  %-22s  %-10s  %-8s  %s" % (r.get("run_at","?"), status, changes, severity)
        except Exception as e:
            print "  [error reading %s: %s]" % (os.path.basename(path), e)
    hr("=")


def update_baseline():
    """Capture a fresh baseline from DMGR"""
    hr("=")
    print "  Updating WebSphere Config Baseline"
    hr("=")

    sys.path.insert(0, SCRIPTS_DIR)
    import extract_baseline as extractor

    print "Capturing configuration from DMGR..."
    snap = extractor.build_snapshot()

    # Archive old baseline
    old_path = os.path.join(BASELINE_DIR, "baseline.json")
    if os.path.exists(old_path):
        ts       = time.strftime("%Y%m%d_%H%M%S")
        arch_dir = os.path.join(BASELINE_DIR, "archive")
        if not os.path.exists(arch_dir):
            os.makedirs(arch_dir)
        import shutil
        shutil.copy2(old_path, os.path.join(arch_dir, "baseline_%s.json" % ts))
        print "Previous baseline archived."

    extractor.write_json(old_path, snap)
    print "New baseline saved: %s" % old_path
    print "Composite hash  : %s" % snap["composite_hash"]
    print "Timestamp       : %s" % snap["metadata"]["timestamp"]
    hr("=")


def compare_specific(snapshot_file=None):
    """Compare live config vs a specific snapshot or baseline"""
    sys.path.insert(0, SCRIPTS_DIR)
    import extract_baseline as extractor
    import detect_drift     as detector

    if snapshot_file:
        ref_path = snapshot_file
    else:
        ref_path = os.path.join(BASELINE_DIR, "baseline.json")

    print "Loading reference: %s" % ref_path
    reference = extractor.read_json(ref_path)

    print "Capturing live configuration..."
    live_snap = extractor.build_snapshot()

    report = detector.build_drift_report(reference, live_snap)

    if report["drift_detected"]:
        print "\n*** %d changes found (Severity: %s) ***\n" % (
            report["total_changes"], report["severity"])
        for ch in report["changes"][:50]:
            print "  [%s] %s" % (ch["change_type"], ch["path"])
            print "    Baseline: %s" % str(ch.get("baseline_value",""))[:80]
            print "    Live    : %s" % str(ch.get("live_value",""))[:80]
            print ""
        if report["total_changes"] > 50:
            print "  ... and %d more changes." % (report["total_changes"] - 50)
    else:
        print "No drift detected."


# ── Command dispatch ─────────────────────────
if __name__ == "__main__" or True:
    cmd = "status"
    if len(sys.argv) > 1:
        cmd = sys.argv[1]

    if cmd == "status":
        print_status()
    elif cmd == "history":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
        print_history(n)
    elif cmd == "update-baseline":
        update_baseline()
    elif cmd == "compare":
        snap_file = sys.argv[2] if len(sys.argv) > 2 else None
        compare_specific(snap_file)
    else:
        print "Unknown command: %s" % cmd
        print __doc__
