#!/bin/bash
# =============================================================================
#  WebSphere Drift Monitor – First-Time Setup & Baseline Capture
#  Run once as wasadmin to initialise the monitoring framework.
# =============================================================================

set -euo pipefail

# ── CONFIGURATION ─────────────────────────────────────────────────────────────
MONITOR_HOME="/opt/drift-monitor"
WAS_HOME="${WAS_HOME:-/opt/IBM/WebSphere/AppServer}"
DMGR_PROFILE="${DMGR_PROFILE:-/opt/IBM/WebSphere/AppServer/profiles/Dmgr01}"
DMGR_HOST="${DMGR_HOST:-localhost}"
DMGR_SOAP_PORT="${DMGR_SOAP_PORT:-8879}"
WSADMIN_USER="${WSADMIN_USER:-wsadmin}"

SCRIPTS_SRC="$(dirname "$(readlink -f "$0")")/../scripts"

echo "============================================================"
echo " WebSphere Config Drift Monitor – Setup"
echo "============================================================"

# ── 1. Create directory structure ─────────────────────────────────────────────
echo "[1/6] Creating directory structure under ${MONITOR_HOME}..."
mkdir -p "${MONITOR_HOME}"/{baseline,snapshots,reports,scripts,bin,conf,logs}

# ── 2. Copy scripts ───────────────────────────────────────────────────────────
echo "[2/6] Copying Jython scripts..."
cp "${SCRIPTS_SRC}/extract_baseline.py" "${MONITOR_HOME}/scripts/"
cp "${SCRIPTS_SRC}/detect_drift.py"     "${MONITOR_HOME}/scripts/"
cp "$(dirname "$(readlink -f "$0")")/run_drift_check.sh" "${MONITOR_HOME}/bin/"
chmod +x "${MONITOR_HOME}/bin/run_drift_check.sh"

# ── 3. Configure email ────────────────────────────────────────────────────────
echo "[3/6] Configure email settings in detect_drift.py"
read -p "  Internal SMTP relay host : " smtp_host
read -p "  Alert FROM address       : " email_from
read -p "  Alert TO addresses (csv) : " email_to_raw

# Convert csv to Python list literal
email_to_list=$(python3 -c "
import json, sys
print(json.dumps([a.strip() for a in '${email_to_raw}'.split(',')]))
" 2>/dev/null || echo '["'"${email_to_raw}"'"]')

sed -i \
    -e "s|SMTP_HOST.*=.*|SMTP_HOST      = \"${smtp_host}\"|" \
    -e "s|EMAIL_FROM.*=.*|EMAIL_FROM     = \"${email_from}\"|" \
    -e "s|EMAIL_TO.*=.*|EMAIL_TO       = ${email_to_list}|" \
    "${MONITOR_HOME}/scripts/detect_drift.py"

echo "  Email settings saved (unauthenticated relay on port 25 – no credentials needed)."

# ── 4. Store wsadmin password securely ────────────────────────────────────────
echo "[4/6] Storing wsadmin credentials..."
read -p "  wsadmin username [wsadmin]: " ws_user; ws_user="${ws_user:-wsadmin}"
read -s -p "  wsadmin password         : " ws_pass; echo

echo "${ws_pass}" > "${MONITOR_HOME}/conf/.wsadmin.pass"
chmod 600 "${MONITOR_HOME}/conf/.wsadmin.pass"
chown "$(whoami)" "${MONITOR_HOME}/conf/.wsadmin.pass"

# ── 5. Capture initial baseline ───────────────────────────────────────────────
echo "[5/6] Capturing initial baseline configuration from DMGR..."
WSADMIN="${DMGR_PROFILE}/bin/wsadmin.sh"

"${WSADMIN}" \
    -lang jython \
    -host "${DMGR_HOST}" \
    -port "${DMGR_SOAP_PORT}" \
    -conntype SOAP \
    -user "${ws_user}" \
    -password "${ws_pass}" \
    -f "${MONITOR_HOME}/scripts/extract_baseline.py" \
    baseline 2>&1 | tee "${MONITOR_HOME}/logs/setup.log"

if [ ! -f "${MONITOR_HOME}/baseline/baseline.json" ]; then
    echo "ERROR: Baseline file was not created. Check logs at ${MONITOR_HOME}/logs/setup.log"
    exit 1
fi
echo "  Baseline saved successfully."

# ── 6. Install cron job ───────────────────────────────────────────────────────
echo "[6/6] Installing cron job (every 60 minutes)..."
CRON_LINE="0 * * * * MONITOR_HOME=${MONITOR_HOME} DMGR_PROFILE=${DMGR_PROFILE} DMGR_HOST=${DMGR_HOST} DMGR_SOAP_PORT=${DMGR_SOAP_PORT} WSADMIN_USER=${ws_user} WSADMIN_PASS_FILE=${MONITOR_HOME}/conf/.wsadmin.pass ${MONITOR_HOME}/bin/run_drift_check.sh >> ${MONITOR_HOME}/logs/cron.log 2>&1"

# Add to crontab if not already present
( crontab -l 2>/dev/null | grep -v "run_drift_check.sh"; echo "${CRON_LINE}" ) | crontab -
echo "  Cron job installed."

echo ""
echo "============================================================"
echo " Setup Complete!"
echo "============================================================"
echo " Baseline : ${MONITOR_HOME}/baseline/baseline.json"
echo " Cron     : every hour at :00"
echo " Logs     : ${MONITOR_HOME}/logs/"
echo " Reports  : ${MONITOR_HOME}/reports/"
echo ""
echo " To run an immediate drift check:"
echo "   ${MONITOR_HOME}/bin/run_drift_check.sh"
echo ""
echo " To refresh the baseline (after approved changes):"
echo "   wsadmin.sh -lang jython -f ${MONITOR_HOME}/scripts/extract_baseline.py baseline"
echo "============================================================"
