"""
WebSphere Configuration Drift Detector
Compares live snapshot against baseline and produces a structured drift report.
Run via: wsadmin.sh -lang jython -f detect_drift.py
"""

import os
import sys
import time
import json
import smtplib
import hashlib

# ─────────────────────────────────────────────
# CONFIGURATION  – edit before deployment
# ─────────────────────────────────────────────
BASELINE_DIR   = "/opt/drift-monitor/baseline"
SNAPSHOT_DIR   = "/opt/drift-monitor/snapshots"
REPORT_DIR     = "/opt/drift-monitor/reports"
LOG_FILE       = "/opt/drift-monitor/logs/drift.log"

# Email settings
SMTP_HOST      = "smtp.yourcompany.com"
SMTP_PORT      = 587
SMTP_USER      = "was-monitor@yourcompany.com"
SMTP_PASS      = "CHANGE_ME"
EMAIL_FROM     = "was-monitor@yourcompany.com"
EMAIL_TO       = ["websphere-ops@yourcompany.com", "middleware-team@yourcompany.com"]
EMAIL_SUBJECT  = "[ALERT] WebSphere Config Drift Detected – {cell} – {timestamp}"

# Drift thresholds
IGNORED_ATTRS  = ["lastModified", "modifiedBy", "deploymentDescriptorVersion"]

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def log(msg):
    ts   = time.strftime("%Y-%m-%d %H:%M:%S")
    line = "[%s] %s" % (ts, msg)
    print line
    try:
        fh = open(LOG_FILE, "a")
        fh.write(line + "\n")
        fh.close()
    except:
        pass


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def read_json(path):
    fh   = open(path, "r")
    data = json.loads(fh.read())
    fh.close()
    return data


def write_json(path, data):
    fh = open(path, "w")
    fh.write(json.dumps(data, indent=2, sort_keys=True))
    fh.close()


def sha256_str(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def is_ignored_attr(key):
    for ig in IGNORED_ATTRS:
        if ig.lower() in key.lower():
            return True
    return False


# ─────────────────────────────────────────────
# DEEP DIFF ENGINE
# ─────────────────────────────────────────────

def diff_strings(baseline_str, live_str, path):
    """
    Parse WebSphere attribute strings like:
      [name myServer] [startingWeight 2] ...
    and diff them key-by-key.
    """
    changes = []

    def parse_attrs(attr_str):
        attrs = {}
        import re
        for m in re.finditer(r"\[(\S+)\s+(.*?)\]", attr_str):
            key, val = m.group(1), m.group(2).strip()
            if not is_ignored_attr(key):
                attrs[key] = val
        return attrs

    b_attrs = parse_attrs(baseline_str)
    l_attrs = parse_attrs(live_str)

    all_keys = set(b_attrs.keys()) | set(l_attrs.keys())
    for key in sorted(all_keys):
        bv = b_attrs.get(key, "<MISSING>")
        lv = l_attrs.get(key, "<MISSING>")
        if bv != lv:
            changes.append({
                "path"          : "%s.%s" % (path, key),
                "baseline_value": bv,
                "live_value"    : lv,
                "change_type"   : "MODIFIED" if bv != "<MISSING>" and lv != "<MISSING>"
                                  else ("ADDED" if bv == "<MISSING>" else "REMOVED"),
            })
    return changes


def diff_section(baseline_data, live_data, section_name):
    """Recursively diff a section (dict, string, or nested)"""
    changes = []

    if isinstance(baseline_data, dict) and isinstance(live_data, dict):
        all_keys = set(baseline_data.keys()) | set(live_data.keys())
        for key in sorted(all_keys):
            if key in ("id",):           # skip internal WAS IDs
                continue
            bv = baseline_data.get(key)
            lv = live_data.get(key)
            path = "%s.%s" % (section_name, key)

            if bv is None and lv is not None:
                changes.append({"path": path, "baseline_value": None,
                                 "live_value": str(lv)[:200], "change_type": "ADDED"})
            elif bv is not None and lv is None:
                changes.append({"path": path, "baseline_value": str(bv)[:200],
                                 "live_value": None, "change_type": "REMOVED"})
            elif isinstance(bv, str) and isinstance(lv, str):
                if bv != lv:
                    sub = diff_strings(bv, lv, path)
                    if sub:
                        changes.extend(sub)
                    else:
                        # raw mismatch not parseable into attrs
                        changes.append({"path": path,
                                         "baseline_value": bv[:300],
                                         "live_value"    : lv[:300],
                                         "change_type"   : "MODIFIED"})
            else:
                changes.extend(diff_section(bv, lv, path))

    elif isinstance(baseline_data, str) and isinstance(live_data, str):
        if baseline_data != live_data:
            sub = diff_strings(baseline_data, live_data, section_name)
            changes.extend(sub) if sub else changes.append({
                "path": section_name,
                "baseline_value": baseline_data[:300],
                "live_value"    : live_data[:300],
                "change_type"   : "MODIFIED",
            })
    else:
        if str(baseline_data) != str(live_data):
            changes.append({
                "path"          : section_name,
                "baseline_value": str(baseline_data)[:300],
                "live_value"    : str(live_data)[:300],
                "change_type"   : "MODIFIED",
            })

    return changes


# ─────────────────────────────────────────────
# REPORT BUILDER
# ─────────────────────────────────────────────

def build_drift_report(baseline, live_snap):
    report = {
        "run_at"             : time.strftime("%Y-%m-%dT%H:%M:%S"),
        "cell"               : live_snap["metadata"]["cell"],
        "baseline_timestamp" : baseline["metadata"]["timestamp"],
        "live_timestamp"     : live_snap["metadata"]["timestamp"],
        "baseline_hash"      : baseline["composite_hash"],
        "live_hash"          : live_snap["composite_hash"],
        "drift_detected"     : baseline["composite_hash"] != live_snap["composite_hash"],
        "section_summary"    : {},
        "changes"            : [],
    }

    if not report["drift_detected"]:
        log("No drift detected – composite hash unchanged.")
        return report

    # Per-section hash check first (fast path)
    b_hashes = baseline.get("hashes", {})
    l_hashes = live_snap.get("hashes", {})
    dirty_sections = []
    for section in b_hashes:
        if b_hashes.get(section) != l_hashes.get(section):
            dirty_sections.append(section)
    for section in l_hashes:
        if section not in b_hashes:
            dirty_sections.append(section)

    log("Dirty sections: %s" % dirty_sections)

    # Deep diff only dirty sections
    all_changes = []
    section_summary = {}
    b_sections = baseline.get("sections", {})
    l_sections = live_snap.get("sections", {})

    for section in dirty_sections:
        b_data = b_sections.get(section, {})
        l_data = l_sections.get(section, {})
        ch     = diff_section(b_data, l_data, section)
        section_summary[section] = {"change_count": len(ch), "status": "DRIFTED"}
        all_changes.extend(ch)

    for section in b_hashes:
        if section not in dirty_sections:
            section_summary[section] = {"change_count": 0, "status": "OK"}

    report["section_summary"] = section_summary
    report["changes"]         = all_changes
    report["total_changes"]   = len(all_changes)

    # Severity classification
    critical_keywords = ["security", "ssl", "jvm", "datasource", "cluster"]
    critical_changes  = [c for c in all_changes
                         if any(kw in c["path"].lower() for kw in critical_keywords)]
    report["critical_change_count"] = len(critical_changes)
    report["severity"] = (
        "CRITICAL" if critical_changes else
        "HIGH"     if len(all_changes) > 20 else
        "MEDIUM"   if len(all_changes) > 5 else
        "LOW"
    )

    return report


# ─────────────────────────────────────────────
# EMAIL NOTIFICATION
# ─────────────────────────────────────────────

def build_email_body(report):
    lines = []

    lines.append("=" * 70)
    lines.append("  WebSphere Configuration Drift Alert")
    lines.append("=" * 70)
    lines.append("")
    lines.append("Cell            : %s" % report["cell"])
    lines.append("Detection Time  : %s" % report["run_at"])
    lines.append("Severity        : *** %s ***" % report["severity"])
    lines.append("Total Changes   : %d" % report["total_changes"])
    lines.append("Critical Changes: %d" % report["critical_change_count"])
    lines.append("")
    lines.append("Baseline taken  : %s" % report["baseline_timestamp"])
    lines.append("Live snapshot   : %s" % report["live_timestamp"])
    lines.append("Baseline hash   : %s" % report["baseline_hash"])
    lines.append("Live hash       : %s" % report["live_hash"])
    lines.append("")
    lines.append("─" * 70)
    lines.append("SECTION SUMMARY")
    lines.append("─" * 70)

    for sec, info in sorted(report["section_summary"].items()):
        icon   = "✗" if info["status"] == "DRIFTED" else "✓"
        status = "%s  %-30s  %s  (%d changes)" % (
            icon, sec, info["status"], info["change_count"])
        lines.append(status)

    lines.append("")
    lines.append("─" * 70)
    lines.append("DETAILED CHANGES")
    lines.append("─" * 70)

    for i, ch in enumerate(report["changes"], 1):
        lines.append("")
        lines.append("[%d] PATH        : %s" % (i, ch["path"]))
        lines.append("    TYPE        : %s" % ch["change_type"])
        bv = ch.get("baseline_value") or "<null>"
        lv = ch.get("live_value")     or "<null>"
        lines.append("    BASELINE    : %s" % str(bv)[:120])
        lines.append("    LIVE        : %s" % str(lv)[:120])

    lines.append("")
    lines.append("─" * 70)
    lines.append("ACTION REQUIRED")
    lines.append("─" * 70)
    lines.append("1. Review changes above and verify if they are authorised.")
    lines.append("2. If unauthorised, roll back via WAS admin console or wsadmin.")
    lines.append("3. If authorised, update the baseline by running:")
    lines.append("   wsadmin.sh -lang jython -f extract_baseline.py baseline")
    lines.append("4. Detailed JSON report saved to: %s" % REPORT_DIR)
    lines.append("")
    lines.append("This alert was generated by the WebSphere Drift Monitor.")
    lines.append("=" * 70)

    return "\n".join(lines)


def send_email(report):
    subject = EMAIL_SUBJECT.format(
        cell      = report["cell"],
        timestamp = report["run_at"].replace("T", " "),
        severity  = report["severity"],
    )
    body = build_email_body(report)

    mime_msg  = "From: %s\r\nTo: %s\r\nSubject: [%s] %s\r\n\r\n%s" % (
        EMAIL_FROM,
        ", ".join(EMAIL_TO),
        report["severity"],
        subject,
        body,
    )

    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
        server.ehlo()
        server.starttls()
        server.login(SMTP_USER, SMTP_PASS)
        server.sendmail(EMAIL_FROM, EMAIL_TO, mime_msg)
        server.quit()
        log("Alert email sent to: %s" % EMAIL_TO)
    except Exception as e:
        log("ERROR: Failed to send email: %s" % str(e))


# ─────────────────────────────────────────────
# MAIN DRIFT CHECK
# ─────────────────────────────────────────────

def run_drift_check():
    ensure_dir(REPORT_DIR)
    ensure_dir(os.path.dirname(LOG_FILE))

    # Load baseline
    baseline_path = os.path.join(BASELINE_DIR, "baseline.json")
    if not os.path.exists(baseline_path):
        log("ERROR: No baseline found at %s. Run extract_baseline.py first." % baseline_path)
        sys.exit(1)

    log("Loading baseline from: %s" % baseline_path)
    baseline = read_json(baseline_path)

    # Capture live snapshot (import the extractor)
    log("Capturing live configuration snapshot...")
    # We import the extractor functions directly
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import extract_baseline as extractor
    live_snap = extractor.build_snapshot()

    # Save the live snapshot for audit trail
    ts        = time.strftime("%Y%m%d_%H%M%S")
    snap_path = os.path.join(SNAPSHOT_DIR, "snapshot_%s.json" % ts)
    write_json(snap_path, live_snap)
    log("Live snapshot saved: %s" % snap_path)

    # Build drift report
    report = build_drift_report(baseline, live_snap)

    # Save report
    rpt_path = os.path.join(REPORT_DIR, "drift_report_%s.json" % ts)
    write_json(rpt_path, report)
    log("Report saved: %s" % rpt_path)

    if report["drift_detected"]:
        log("DRIFT DETECTED! %d changes found. Severity: %s" % (
            report["total_changes"], report["severity"]))
        send_email(report)
    else:
        log("No drift detected. Configuration matches baseline.")

    # Cleanup old snapshots (keep last 72 = 3 days at 60-min intervals)
    cleanup_old_files(SNAPSHOT_DIR, "snapshot_", keep=72)
    cleanup_old_files(REPORT_DIR,   "drift_report_", keep=72)


def cleanup_old_files(directory, prefix, keep=72):
    try:
        files = sorted([f for f in os.listdir(directory) if f.startswith(prefix)])
        for old in files[:-keep]:
            os.remove(os.path.join(directory, old))
    except:
        pass


# ── entry ─────────────────────────────────────
if __name__ == "__main__" or True:
    run_drift_check()
