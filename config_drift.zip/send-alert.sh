#!/usr/bin/env bash
# =============================================================================
# send-alert.sh
# Sends the drift report by email. Prefers sendmail/mailx if present,
# otherwise falls back to a Python SMTP client for portability.
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1090
source "${SCRIPT_DIR}/../config/drift-detector.conf"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib-common.sh"

SUBJECT=""
HTML_FILE=""
ATTACHMENTS=()
ADDED=0; REMOVED=0; MODIFIED=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --subject) SUBJECT="$2"; shift 2 ;;
        --html) HTML_FILE="$2"; shift 2 ;;
        --attach) ATTACHMENTS+=("$2"); shift 2 ;;
        --summary-added) ADDED="$2"; shift 2 ;;
        --summary-removed) REMOVED="$2"; shift 2 ;;
        --summary-modified) MODIFIED="$2"; shift 2 ;;
        *) die "Unknown arg: $1" ;;
    esac
done

[[ -n "$SUBJECT" ]] || die "Missing --subject"
[[ -r "$HTML_FILE" ]] || die "Missing/unreadable HTML report: $HTML_FILE"

# Build inline diff preview (truncated)
PREVIEW=""
if [[ ${#ATTACHMENTS[@]} -gt 0 && -r "${ATTACHMENTS[0]}" ]]; then
    PREVIEW="$(head -c "${MAIL_INLINE_DIFF_BYTES}" "${ATTACHMENTS[0]}")"
    if (( $(wc -c < "${ATTACHMENTS[0]}") > MAIL_INLINE_DIFF_BYTES )); then
        PREVIEW="${PREVIEW}

[...truncated — see attachment for full diff...]"
    fi
fi

# Prefer Python SMTP for reliable HTML + attachment handling
if command -v python3 >/dev/null 2>&1; then
    log_info "Sending via Python SMTP -> ${MAIL_SMTP_HOST}:${MAIL_SMTP_PORT}"
    SMTP_PASS=""
    if [[ -n "${MAIL_SMTP_PASS_FILE:-}" && -r "${MAIL_SMTP_PASS_FILE}" ]]; then
        SMTP_PASS="$(< "${MAIL_SMTP_PASS_FILE}")"
    fi

    MAIL_FROM="$MAIL_FROM" \
    MAIL_TO="$MAIL_TO" \
    MAIL_SUBJECT="$SUBJECT" \
    MAIL_SMTP_HOST="$MAIL_SMTP_HOST" \
    MAIL_SMTP_PORT="$MAIL_SMTP_PORT" \
    MAIL_SMTP_USER="$MAIL_SMTP_USER" \
    MAIL_SMTP_PASS="$SMTP_PASS" \
    MAIL_USE_TLS="$MAIL_USE_TLS" \
    HTML_FILE="$HTML_FILE" \
    PREVIEW="$PREVIEW" \
    ADDED="$ADDED" REMOVED="$REMOVED" MODIFIED="$MODIFIED" \
    ATTACHMENTS_JOINED="$(IFS='|'; echo "${ATTACHMENTS[*]:-}")" \
    python3 "${SCRIPT_DIR}/send-smtp.py"
    exit $?
fi

# Fallback: mailx with attachments (works on most AIX/RHEL portal hosts)
if command -v mailx >/dev/null 2>&1; then
    log_info "Sending via mailx"
    attach_args=()
    for a in "${ATTACHMENTS[@]}"; do
        [[ -r "$a" ]] && attach_args+=(-a "$a")
    done
    {
        echo "Configuration drift detected on ${HOSTNAME_TAG}."
        echo
        echo "Summary: ${ADDED} added, ${REMOVED} removed, ${MODIFIED} modified"
        echo
        echo "----- Diff preview -----"
        echo "$PREVIEW"
        echo
        echo "Full HTML report attached."
    } | mailx -s "$SUBJECT" -r "$MAIL_FROM" "${attach_args[@]}" -a "$HTML_FILE" "$MAIL_TO"
    exit $?
fi

die "No mail transport available (need python3 or mailx)"
