#!/usr/bin/env bash
# =============================================================================
# check-drift.sh
# Compares current WebSphere + HCL Portal config against the trusted baseline.
# Emits an HTML report and, if drift is found, an email alert.
# Exit codes: 0 = no drift, 1 = drift detected, 2 = error
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="${SCRIPT_DIR}/../config/drift-detector.conf"
# shellcheck disable=SC1090
source "$CONF"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib-common.sh"

mkdir -p "${BASELINE_DIR}" "${REPORT_DIR}" "${LOG_DIR}" "${DIFF_SNAPSHOT_DIR}"

BASELINE_FILE="${BASELINE_DIR}/baseline.snapshot"
[[ -r "${BASELINE_FILE}" ]] || die "No baseline found at ${BASELINE_FILE}. Run capture-baseline.sh first."

TS="$(date '+%Y%m%d-%H%M%S')"
CURRENT_FILE="${BASELINE_DIR}/current-${TS}.snapshot"
CURRENT_TREE="${DIFF_SNAPSHOT_DIR}/current-${TS}"
REPORT_FILE="${REPORT_DIR}/drift-report-${TS}.html"
DIFF_FILE="${REPORT_DIR}/drift-diff-${TS}.txt"

log_info "Generating current snapshot…"
generate_snapshot > "${CURRENT_FILE}"

# Snapshot current files for accurate diffs
mkdir -p "${CURRENT_TREE}"
while IFS= read -r line; do
    abs_path="${line#*  }"
    [[ "$abs_path" == "PORTAL-XMLACCESS-EXPORT" ]] && continue
    rel_path="${abs_path#/}"
    dest="${CURRENT_TREE}/${rel_path}"
    mkdir -p "$(dirname "$dest")"
    cp -p "$abs_path" "$dest" 2>/dev/null || true
done < "${CURRENT_FILE}"

if portal_export="$(export_portal_xmlaccess "${CURRENT_TREE}")" && [[ -n "$portal_export" ]]; then
    portal_hash="$(hash_file "$portal_export")"
    printf '%s  %s\n' "$portal_hash" "PORTAL-XMLACCESS-EXPORT" >> "${CURRENT_FILE}"
    LC_ALL=C sort -k2 -o "${CURRENT_FILE}" "${CURRENT_FILE}"
fi

# ---------- Compare manifests ------------------------------------------------
# Build associative arrays of path -> hash for both snapshots.
declare -A BASELINE_HASHES CURRENT_HASHES
while IFS= read -r line; do
    h="${line%%  *}"; p="${line#*  }"
    BASELINE_HASHES["$p"]="$h"
done < "${BASELINE_FILE}"
while IFS= read -r line; do
    h="${line%%  *}"; p="${line#*  }"
    CURRENT_HASHES["$p"]="$h"
done < "${CURRENT_FILE}"

ADDED=()
REMOVED=()
MODIFIED=()

for p in "${!CURRENT_HASHES[@]}"; do
    if [[ -z "${BASELINE_HASHES[$p]:-}" ]]; then
        ADDED+=("$p")
    elif [[ "${BASELINE_HASHES[$p]}" != "${CURRENT_HASHES[$p]}" ]]; then
        MODIFIED+=("$p")
    fi
done
for p in "${!BASELINE_HASHES[@]}"; do
    if [[ -z "${CURRENT_HASHES[$p]:-}" ]]; then
        REMOVED+=("$p")
    fi
done

TOTAL_DRIFT=$(( ${#ADDED[@]} + ${#REMOVED[@]} + ${#MODIFIED[@]} ))
log_info "Drift summary: ${#ADDED[@]} added, ${#REMOVED[@]} removed, ${#MODIFIED[@]} modified"

# ---------- Build textual diff ----------------------------------------------
BASELINE_TREE="${DIFF_SNAPSHOT_DIR}/baseline"
{
    echo "Configuration Drift Report"
    echo "Generated: $(date)"
    echo "Host:      ${HOSTNAME_TAG}"
    echo "Profile:   ${WAS_PROFILE_NAME} (cell: ${WAS_CELL_NAME})"
    echo "============================================================"
    echo
    echo "ADDED FILES (${#ADDED[@]})"
    echo "------------"
    printf '  + %s\n' "${ADDED[@]:-(none)}"
    echo
    echo "REMOVED FILES (${#REMOVED[@]})"
    echo "------------"
    printf '  - %s\n' "${REMOVED[@]:-(none)}"
    echo
    echo "MODIFIED FILES (${#MODIFIED[@]})"
    echo "------------"
    for p in "${MODIFIED[@]:-}"; do
        [[ -z "$p" ]] && continue
        echo
        echo "##### ${p} #####"
        rel="${p#/}"
        old="${BASELINE_TREE}/${rel}"
        new="${CURRENT_TREE}/${rel}"
        if [[ "$p" == "PORTAL-XMLACCESS-EXPORT" ]]; then
            old="${BASELINE_TREE}/portal-xmlaccess-export.xml"
            new="${CURRENT_TREE}/portal-xmlaccess-export.xml"
        fi
        if [[ -r "$old" && -r "$new" ]]; then
            diff -u --label "BASELINE/${rel}" --label "CURRENT/${rel}" "$old" "$new" 2>/dev/null | head -200
        else
            echo "(content diff unavailable — baseline or current file missing on disk)"
        fi
    done
} > "${DIFF_FILE}"

# ---------- Build HTML report ------------------------------------------------
status_color="#16a34a"; status_text="NO DRIFT DETECTED"
if (( TOTAL_DRIFT > 0 )); then
    status_color="#dc2626"; status_text="DRIFT DETECTED"
fi

html_escape() { sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g'; }

{
cat <<EOF
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Config Drift Report ${TS}</title>
<style>
 body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;padding:24px;background:#f8fafc;color:#0f172a}
 .banner{background:${status_color};color:#fff;padding:16px 24px;border-radius:8px;font-size:20px;font-weight:600}
 h2{border-bottom:2px solid #e2e8f0;padding-bottom:6px;margin-top:32px}
 .meta{background:#fff;border:1px solid #e2e8f0;padding:12px 16px;border-radius:6px;margin-top:16px}
 .meta dt{font-weight:600;color:#475569;display:inline-block;width:140px}
 .counts{display:flex;gap:16px;margin-top:16px}
 .count{background:#fff;border:1px solid #e2e8f0;padding:12px 20px;border-radius:6px;flex:1;text-align:center}
 .count .n{font-size:28px;font-weight:700}
 .added .n{color:#16a34a}.removed .n{color:#dc2626}.modified .n{color:#d97706}
 ul.files{background:#fff;border:1px solid #e2e8f0;border-radius:6px;padding:12px 16px 12px 32px;font-family:ui-monospace,Consolas,monospace;font-size:13px}
 pre.diff{background:#0f172a;color:#e2e8f0;padding:16px;border-radius:6px;overflow-x:auto;font-size:12px;line-height:1.4}
 pre.diff .add{color:#86efac}.diff .del{color:#fca5a5}.diff .hdr{color:#7dd3fc;font-weight:600}
</style></head><body>
<div class="banner">${status_text} &mdash; ${HOSTNAME_TAG}</div>
<div class="meta">
  <dl>
    <dt>Generated:</dt><dd>$(date)</dd><br>
    <dt>WAS profile:</dt><dd>${WAS_PROFILE_NAME} (cell ${WAS_CELL_NAME})</dd><br>
    <dt>Baseline:</dt><dd>$(readlink "${BASELINE_FILE}" 2>/dev/null || basename "${BASELINE_FILE}")</dd><br>
    <dt>Files scanned:</dt><dd>$(wc -l < "${CURRENT_FILE}")</dd>
  </dl>
</div>
<div class="counts">
  <div class="count added"><div class="n">${#ADDED[@]}</div>Added</div>
  <div class="count removed"><div class="n">${#REMOVED[@]}</div>Removed</div>
  <div class="count modified"><div class="n">${#MODIFIED[@]}</div>Modified</div>
</div>
EOF

if (( ${#ADDED[@]} > 0 )); then
    echo "<h2>Added Files</h2><ul class='files'>"
    for p in "${ADDED[@]}"; do echo "<li>$(printf '%s' "$p" | html_escape)</li>"; done
    echo "</ul>"
fi
if (( ${#REMOVED[@]} > 0 )); then
    echo "<h2>Removed Files</h2><ul class='files'>"
    for p in "${REMOVED[@]}"; do echo "<li>$(printf '%s' "$p" | html_escape)</li>"; done
    echo "</ul>"
fi
if (( ${#MODIFIED[@]} > 0 )); then
    echo "<h2>Modified Files (with diffs)</h2>"
    for p in "${MODIFIED[@]}"; do
        echo "<h3>$(printf '%s' "$p" | html_escape)</h3>"
        rel="${p#/}"
        old="${BASELINE_TREE}/${rel}"
        new="${CURRENT_TREE}/${rel}"
        [[ "$p" == "PORTAL-XMLACCESS-EXPORT" ]] && { old="${BASELINE_TREE}/portal-xmlaccess-export.xml"; new="${CURRENT_TREE}/portal-xmlaccess-export.xml"; }
        echo "<pre class='diff'>"
        if [[ -r "$old" && -r "$new" ]]; then
            diff -u "$old" "$new" 2>/dev/null | head -150 | html_escape \
              | sed -E 's|^(\+\+\+.*)$|<span class="hdr">\1</span>|; s|^(---.*)$|<span class="hdr">\1</span>|; s|^(@@.*@@)$|<span class="hdr">\1</span>|; s|^(\+[^+].*)$|<span class="add">\1</span>|; s|^(-[^-].*)$|<span class="del">\1</span>|'
        else
            echo "(diff unavailable)"
        fi
        echo "</pre>"
    done
fi

echo "</body></html>"
} > "${REPORT_FILE}"

# ---------- Retention --------------------------------------------------------
# Keep last N reports
ls -1t "${REPORT_DIR}"/drift-report-*.html 2>/dev/null | tail -n +$((REPORT_RETENTION + 1)) | xargs -r rm -f
ls -1t "${REPORT_DIR}"/drift-diff-*.txt 2>/dev/null | tail -n +$((REPORT_RETENTION + 1)) | xargs -r rm -f
ls -1td "${DIFF_SNAPSHOT_DIR}"/current-* 2>/dev/null | tail -n +$((REPORT_RETENTION + 1)) | xargs -r rm -rf
ls -1t "${BASELINE_DIR}"/current-*.snapshot 2>/dev/null | tail -n +$((REPORT_RETENTION + 1)) | xargs -r rm -f

# ---------- Send email -------------------------------------------------------
if [[ "${MAIL_ENABLED}" == "true" ]]; then
    if (( TOTAL_DRIFT > 0 )) || [[ "${MAIL_ON_DRIFT_ONLY}" != "true" ]]; then
        log_info "Sending email notification…"
        "${SCRIPT_DIR}/send-alert.sh" \
            --subject "${MAIL_SUBJECT_PREFIX} ${status_text} on ${HOSTNAME_TAG} (${TOTAL_DRIFT} changes)" \
            --html "${REPORT_FILE}" \
            --attach "${DIFF_FILE}" \
            --summary-added "${#ADDED[@]}" \
            --summary-removed "${#REMOVED[@]}" \
            --summary-modified "${#MODIFIED[@]}" \
            || log_error "Email send failed (continuing)"
    else
        log_info "No drift; skipping email (MAIL_ON_DRIFT_ONLY=true)"
    fi
fi

echo
echo "Report:  ${REPORT_FILE}"
echo "Diff:    ${DIFF_FILE}"
echo "Drift:   ${TOTAL_DRIFT} change(s)"

(( TOTAL_DRIFT > 0 )) && exit 1 || exit 0
