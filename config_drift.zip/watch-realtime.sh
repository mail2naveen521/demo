#!/usr/bin/env bash
# =============================================================================
# watch-realtime.sh
# Optional: watch WebSphere/Portal config dirs with inotify and trigger
# check-drift.sh on any change. Use this instead of cron when near-real-time
# alerts are required.
#
# Requires: inotify-tools (Linux). On AIX/Solaris, stick to cron.
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1090
source "${SCRIPT_DIR}/../config/drift-detector.conf"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib-common.sh"

command -v inotifywait >/dev/null 2>&1 || die "inotify-tools not installed"

DEBOUNCE_SEC="${DEBOUNCE_SEC:-30}"
LAST_RUN=0

mapfile -t TARGETS < <(resolve_targets)
[[ ${#TARGETS[@]} -gt 0 ]] || die "No target directories exist on this host"

log_info "Watching ${#TARGETS[@]} directories (debounce ${DEBOUNCE_SEC}s)"
for t in "${TARGETS[@]}"; do log_info "  - $t"; done

inotifywait -m -r -e modify,create,delete,move \
    --format '%w%f %e' \
    "${TARGETS[@]}" 2>/dev/null \
| while read -r path event; do
    # Filter: skip uninteresting files/dirs
    should_exclude "$path" && continue
    case "$path" in
        *.log|*.tmp|*.lck|*.pid) continue ;;
    esac

    now=$(date +%s)
    if (( now - LAST_RUN < DEBOUNCE_SEC )); then
        continue
    fi
    LAST_RUN=$now

    log_info "Change detected: $event $path — running drift check"
    "${SCRIPT_DIR}/check-drift.sh" || true
done
