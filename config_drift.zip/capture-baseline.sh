#!/usr/bin/env bash
# =============================================================================
# capture-baseline.sh
# Captures the current WebSphere + HCL Portal config as the trusted baseline.
# Run this AFTER a known-good config change (deployment, manual fix, etc.).
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="${SCRIPT_DIR}/../config/drift-detector.conf"
# shellcheck disable=SC1090
source "$CONF"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib-common.sh"

mkdir -p "${BASELINE_DIR}" "${DIFF_SNAPSHOT_DIR}" "${LOG_DIR}"

TS="$(date '+%Y%m%d-%H%M%S')"
BASELINE_FILE="${BASELINE_DIR}/baseline.snapshot"
ARCHIVE_FILE="${BASELINE_DIR}/baseline-${TS}.snapshot"
SNAPSHOT_ARCHIVE_DIR="${DIFF_SNAPSHOT_DIR}/baseline-${TS}"

log_info "Capturing baseline snapshot…"

# Generate hash manifest
generate_snapshot > "${ARCHIVE_FILE}"
file_count=$(wc -l < "${ARCHIVE_FILE}")
log_info "Hashed ${file_count} files"

# Also archive the actual file contents so we can produce real diffs later
mkdir -p "${SNAPSHOT_ARCHIVE_DIR}"
while IFS= read -r line; do
    abs_path="${line#*  }"
    rel_path="${abs_path#/}"
    dest="${SNAPSHOT_ARCHIVE_DIR}/${rel_path}"
    mkdir -p "$(dirname "$dest")"
    cp -p "$abs_path" "$dest" 2>/dev/null || true
done < "${ARCHIVE_FILE}"

# Capture HCL Portal logical config via xmlaccess (optional)
if portal_export="$(export_portal_xmlaccess "${SNAPSHOT_ARCHIVE_DIR}")" && [[ -n "$portal_export" ]]; then
    portal_hash="$(hash_file "$portal_export")"
    printf '%s  %s\n' "$portal_hash" "PORTAL-XMLACCESS-EXPORT" >> "${ARCHIVE_FILE}"
    LC_ALL=C sort -k2 -o "${ARCHIVE_FILE}" "${ARCHIVE_FILE}"
    log_info "Captured Portal xmlaccess export"
fi

# Promote to active baseline
ln -sfn "$(basename "${ARCHIVE_FILE}")" "${BASELINE_FILE}"
ln -sfn "$(basename "${SNAPSHOT_ARCHIVE_DIR}")" "${DIFF_SNAPSHOT_DIR}/baseline"

# Metadata
cat > "${BASELINE_DIR}/baseline.meta" <<EOF
captured_at=${TS}
captured_by=$(id -un)@${HOSTNAME_TAG}
was_profile=${WAS_PROFILE_NAME}
was_cell=${WAS_CELL_NAME}
file_count=${file_count}
EOF

log_info "Baseline captured: ${ARCHIVE_FILE}"
log_info "Active baseline symlink: ${BASELINE_FILE}"
echo
echo "Baseline ready. Run check-drift.sh to detect changes."
