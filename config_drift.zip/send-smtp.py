#!/usr/bin/env python3
"""
send-smtp.py — send the drift alert via SMTP.

All configuration arrives through environment variables (set by send-alert.sh).
Sends a multipart/alternative + mixed message: plain-text preview, HTML report,
and full diff as attachment.
"""
import os
import sys
import smtplib
import mimetypes
from email.message import EmailMessage
from pathlib import Path


def env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


def main() -> int:
    sender = env("MAIL_FROM")
    recipients = [r.strip() for r in env("MAIL_TO").split(",") if r.strip()]
    subject = env("MAIL_SUBJECT")
    host = env("MAIL_SMTP_HOST")
    port = int(env("MAIL_SMTP_PORT", "25"))
    user = env("MAIL_SMTP_USER")
    password = env("MAIL_SMTP_PASS")
    use_tls = env("MAIL_USE_TLS", "false").lower() == "true"
    html_path = Path(env("HTML_FILE"))
    preview = env("PREVIEW", "")
    added = env("ADDED", "0")
    removed = env("REMOVED", "0")
    modified = env("MODIFIED", "0")
    attachments = [a for a in env("ATTACHMENTS_JOINED", "").split("|") if a]

    if not (sender and recipients and subject and html_path.is_file()):
        print("send-smtp: missing required inputs", file=sys.stderr)
        return 2

    html_body = html_path.read_text(encoding="utf-8", errors="replace")

    plain_body = (
        f"WebSphere / HCL Portal configuration drift report\n"
        f"--------------------------------------------------\n"
        f"Host:     {os.uname().nodename}\n"
        f"Summary:  {added} added, {removed} removed, {modified} modified\n\n"
        f"Diff preview\n"
        f"------------\n"
        f"{preview}\n\n"
        f"Full HTML report and diff are attached.\n"
    )

    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content(plain_body)
    msg.add_alternative(html_body, subtype="html")

    for path_str in attachments:
        p = Path(path_str)
        if not p.is_file():
            continue
        ctype, _ = mimetypes.guess_type(p.name)
        maintype, subtype = (ctype.split("/", 1) if ctype else ("application", "octet-stream"))
        msg.add_attachment(
            p.read_bytes(),
            maintype=maintype,
            subtype=subtype,
            filename=p.name,
        )

    # Also attach the HTML report itself so recipients can open offline
    msg.add_attachment(
        html_body.encode("utf-8"),
        maintype="text",
        subtype="html",
        filename=html_path.name,
    )

    try:
        if use_tls and port == 465:
            smtp = smtplib.SMTP_SSL(host, port, timeout=30)
        else:
            smtp = smtplib.SMTP(host, port, timeout=30)
        with smtp:
            smtp.ehlo()
            if use_tls and port != 465:
                smtp.starttls()
                smtp.ehlo()
            if user and password:
                smtp.login(user, password)
            smtp.send_message(msg, from_addr=sender, to_addrs=recipients)
    except Exception as exc:
        print(f"send-smtp: {exc}", file=sys.stderr)
        return 1

    print(f"send-smtp: delivered to {len(recipients)} recipient(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
