#!/usr/bin/env bash
# =============================================================================
# install-cron.sh
# Installs a cron entry that runs check-drift.sh every 5 minutes.
# Override the schedule with DRIFT_CRON_SCHEDULE before running.
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCHEDULE="${DRIFT_CRON_SCHEDULE:-*/5 * * * *}"
CRON_LINE="${SCHEDULE} ${SCRIPT_DIR}/check-drift.sh >> ${SCRIPT_DIR}/../logs/cron.log 2>&1"
MARKER="# drift-detector managed entry"

# Pull existing crontab (ignore failure if none)
TMP="$(mktemp)"
crontab -l 2>/dev/null > "$TMP" || true

# Strip any prior managed entry
grep -v -F "${MARKER}" "$TMP" > "${TMP}.new" || true
mv "${TMP}.new" "$TMP"

# Append fresh entry
{
    echo ""
    echo "${MARKER}"
    echo "${CRON_LINE}"
} >> "$TMP"

crontab "$TMP"
rm -f "$TMP"

echo "Installed cron entry: ${CRON_LINE}"
echo "Current crontab:"
crontab -l | grep -A1 "${MARKER}"
