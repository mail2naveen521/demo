#!/bin/bash
###############################################################################
# detect_drift.sh
#
# WebSphere config drift detection orchestrator (v2 - Git-free, no SMTP auth).
#
# Flow:
#   1. wsadmin Jython extractor populates <SNAPSHOTS_ROOT>/current/
#   2. drift_engine.py archives current -> history/snapshot_<ts>/
#      diffs vs prior, sends email if drift, prunes old snapshots.
#
# Schedule via cron, e.g. every 15 minutes:
#   */15 * * * * /opt/was_drift/detect_drift.sh >> /var/log/was_drift/cron.log 2>&1
###############################################################################

set -u

# ---------- Config (override via env or drift.conf) --------------------------
WAS_HOME="${WAS_HOME:-/opt/IBM/WebSphere/AppServer}"
DMGR_PROFILE="${DMGR_PROFILE:-/opt/IBM/WebSphere/AppServer/profiles/Dmgr01}"
SCRIPT_DIR="${SCRIPT_DIR:-/opt/was_drift}"
SNAPSHOTS_ROOT="${SNAPSHOTS_ROOT:-/var/was/drift/snapshots}"
LOG_DIR="${LOG_DIR:-/var/log/was_drift}"
DRIFT_CONF="${DRIFT_CONF:-$SCRIPT_DIR/drift.conf}"

WSADMIN_CONN_TYPE="${WSADMIN_CONN_TYPE:-SOAP}"
WSADMIN_HOST="${WSADMIN_HOST:-localhost}"
WSADMIN_PORT="${WSADMIN_PORT:-8879}"

PYTHON_BIN="${PYTHON_BIN:-/usr/bin/python}"

# ---------- Setup ------------------------------------------------------------
mkdir -p "$LOG_DIR" "$SNAPSHOTS_ROOT"
RUN_TS="$(date +%Y%m%d_%H%M%S)"
RUN_LOG="$LOG_DIR/run_${RUN_TS}.log"

echo "=== WAS Drift Detection run: $RUN_TS ===" | tee -a "$RUN_LOG"

# ---------- 1. Extract -------------------------------------------------------
echo "[1/2] Extracting configuration via wsadmin..." | tee -a "$RUN_LOG"

WSADMIN="$DMGR_PROFILE/bin/wsadmin.sh"
if [ ! -x "$WSADMIN" ]; then
    echo "ERROR: wsadmin.sh not found at $WSADMIN" | tee -a "$RUN_LOG"
    exit 1
fi

"$WSADMIN" \
    -lang jython \
    -conntype "$WSADMIN_CONN_TYPE" \
    -host "$WSADMIN_HOST" \
    -port "$WSADMIN_PORT" \
    -f "$SCRIPT_DIR/extractConfig.py" \
    "$SNAPSHOTS_ROOT" \
    >> "$RUN_LOG" 2>&1
EXTRACT_RC=$?

if [ $EXTRACT_RC -ne 0 ]; then
    echo "ERROR: wsadmin extract failed with rc=$EXTRACT_RC" | tee -a "$RUN_LOG"
    exit $EXTRACT_RC
fi

# ---------- 2. Diff + alert --------------------------------------------------
echo "[2/2] Running drift engine..." | tee -a "$RUN_LOG"

if [ -f "$DRIFT_CONF" ]; then
    "$PYTHON_BIN" "$SCRIPT_DIR/drift_engine.py" "$SNAPSHOTS_ROOT" \
        --config "$DRIFT_CONF" >> "$RUN_LOG" 2>&1
else
    "$PYTHON_BIN" "$SCRIPT_DIR/drift_engine.py" "$SNAPSHOTS_ROOT" \
        >> "$RUN_LOG" 2>&1
fi
ENGINE_RC=$?

echo "=== Done (rc=$ENGINE_RC) ===" | tee -a "$RUN_LOG"
exit $ENGINE_RC
