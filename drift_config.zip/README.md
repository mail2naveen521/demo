# WebSphere Config Drift Detection (v2 — Git-free, no SMTP auth)

Snapshot-and-diff drift detection for WAS 8.5.5.x. **No Git required.**
**No SMTP credentials required.**

## How it differs from v1

| Concern | v1 | v2 |
|---------|----|----|
| Diff storage | Git repo + commits | Plain timestamped directories |
| Diff engine | `git diff` | Python `difflib` (stdlib only) |
| History retention | Git history (unbounded) | Configurable count, oldest pruned |
| Email auth | Required SMTP user/password | None — uses local/internal relay |
| External tools needed | `git`, `mailx`, `curl` | Just `python` + `wsadmin` |

Same drift coverage. Same `.props` files. Same rollback path via
`applyConfigProperties`. Just simpler infrastructure.

## Files

| File | Runtime | Purpose |
|------|---------|---------|
| `extractConfig.py` | wsadmin / Jython 2.1 | Walks cell topology, writes `.props` files into `<root>/current/`, normalizes inline |
| `drift_engine.py` | system Python 2.6+ | Archives `current/` → `history/snapshot_<ts>/`, diffs vs prior, emails alert, prunes old |
| `detect_drift.sh` | bash | Cron driver that calls the two above in sequence |
| `drift.conf` | config file | SMTP relay, recipients, retention settings |

## Directory layout

```
/var/was/drift/snapshots/
├── current/                             ← extractor writes here
│   └── (gets moved to history)
├── history/
│   ├── snapshot_20260430_140000/        ← oldest kept
│   │   ├── cell.props
│   │   ├── nodes/
│   │   ├── servers/
│   │   ├── clusters/
│   │   └── applications/
│   ├── snapshot_20260430_141500/
│   └── snapshot_20260430_143000/        ← most recent
└── last_drift.diff                      ← latest unified diff (always overwritten)
```

## SMTP without authentication — your two realistic options

The `drift_engine.py` script never calls `smtp.login()`. For the relay to
actually accept the message, one of the following must be true:

### Option A: Local MTA on the WAS host (recommended)

Install/configure postfix or sendmail on the DMGR host as a *send-only*
relay. Mail submitted to `localhost:25` is then forwarded by the local MTA
to your corporate mail infrastructure (which trusts known internal hosts).

Postfix minimal config:
```bash
# /etc/postfix/main.cf
myhostname = dmgr01.corp.example.com
mydestination = $myhostname, localhost.$mydomain, localhost
relayhost = [mailrelay.corp.example.com]:25
inet_interfaces = loopback-only      # only accept local connections - secure
```

Then in `drift.conf`: `SMTP_HOST=localhost`

This is by far the most common pattern and is how almost every Linux/AIX
host sends system-generated mail (cron output, mdadm alerts, etc.).

### Option B: Direct connection to internal corporate relay

Many enterprises run an internal SMTP relay that accepts unauthenticated
SMTP from internal IP ranges (typically with an ACL on source IP). If
your WAS hosts are on such a network:

```
# drift.conf
SMTP_HOST=mailrelay.corp.example.com
SMTP_PORT=25
SMTP_USE_TLS=false       # or true if relay requires STARTTLS-without-auth
```

Verify it works manually first:
```bash
python -c "
import smtplib
s = smtplib.SMTP('mailrelay.corp.example.com', 25, timeout=10)
s.ehlo()
s.sendmail('test@dmgr01', ['you@corp.example.com'],
           'Subject: relay test\n\nIf you got this, no auth needed.')
s.quit()
"
```

If that fails with `530 Authentication required`, your relay does require
auth and you'll need to talk to the messaging team about either an
exception by source IP or a service-account password (in which case use
v1 of this solution).

## One-time setup

1. **Install files** on the DMGR host:
   ```
   /opt/was_drift/extractConfig.py
   /opt/was_drift/drift_engine.py
   /opt/was_drift/detect_drift.sh
   /opt/was_drift/drift.conf
   chmod +x /opt/was_drift/detect_drift.sh
   ```

2. **Edit `drift.conf`** with your SMTP relay and recipient addresses.

3. **Test SMTP path manually** (see Option B example above) — confirm a
   test email actually arrives.

4. **First run** (creates baseline, no email):
   ```bash
   /opt/was_drift/detect_drift.sh
   ```
   Expect: `Baseline established. No alert sent on first run.`

5. **Second run** (verifies no false positives):
   ```bash
   /opt/was_drift/detect_drift.sh
   ```
   Expect: `No drift detected.`

6. **Trigger a real test**: change something trivial in the admin console
   (e.g., a JVM custom property `DRIFT_TEST=1`), save & sync, then run again.
   Expect: drift detected, email arrives with diff attached.

7. **Schedule via cron**:
   ```
   */15 * * * * /opt/was_drift/detect_drift.sh >> /var/log/was_drift/cron.log 2>&1
   ```

## Configuration reference (`drift.conf`)

| Key | Default | Purpose |
|-----|---------|---------|
| `SMTP_HOST` | `localhost` | Relay hostname |
| `SMTP_PORT` | `25` | Relay port |
| `SMTP_TIMEOUT` | `30` | Connection timeout (seconds) |
| `SMTP_USE_TLS` | `false` | STARTTLS without auth — set `true` if relay demands TLS |
| `MAIL_FROM` | `was-drift@localhost` | Sender address |
| `MAIL_TO` | `was-admins@example.com` | Comma-separated recipients |
| `MAIL_SUBJECT_TAG` | `[WAS DRIFT]` | Subject prefix for inbox filtering |
| `RETENTION_COUNT` | `30` | Number of snapshots to keep before pruning |
| `MAX_DIFF_BYTES` | `500000` | Truncation cap for diff attachment |

Any of these can also be set as environment variables, which override the
file values — convenient for one-off testing.

## Email format

**Subject**: `[WAS DRIFT] Config change on dmgr01 at 2026-04-30 14:30:00`

**Body** (plain text):
```
WebSphere configuration drift detected.

Host:          dmgr01
Time:          2026-04-30 14:30:00
Snapshot:      snapshot_20260430_143000
Previous:      snapshot_20260430_141500
Snapshots dir: /var/was/drift/snapshots

Summary of changes:
Total: 0 added, 0 removed, 1 modified
  MODIFIED  servers/node01__server1.props

Full unified diff is attached as drift.diff.
```

**Attachment**: `drift.diff` — standard unified diff format, openable in
any text editor / viewable inline in most mail clients.

## Failure handling

| Failure | Behavior |
|---------|----------|
| wsadmin extract fails | `detect_drift.sh` exits with non-zero rc; no snapshot archived; cron output captures the error |
| Extract succeeds but `current/` is empty | Engine refuses to archive an empty snapshot; logs error |
| SMTP relay unreachable / rejects mail | Engine exits rc=3, but `last_drift.diff` is still written to disk so you have local audit |
| Two runs collide on same timestamp | Suffix `_1`, `_2`, etc. appended; no data loss |

The local `last_drift.diff` file is always overwritten on each drift event,
giving you a "what changed most recently" view independent of email delivery.

## Rollback

The `.props` files in any historical snapshot can be replayed:

```bash
$DMGR_PROFILE/bin/wsadmin.sh -lang jython -c \
  "AdminTask.applyConfigProperties(['-propertiesFileName', '/var/was/drift/snapshots/history/snapshot_20260430_141500/servers/node01__server1.props', '-validate', 'true'])"
```

Always run with `-validate true` first and review the report before applying.

## Troubleshooting

**`Connection refused` on SMTP_HOST=localhost**
Local MTA isn't running. `systemctl status postfix` (or sendmail). On AIX,
check `lssrc -s sendmail`.

**`550 Sender address rejected`**
Your relay's policy doesn't accept `MAIL_FROM` as written. Set it to
something the relay considers valid — usually `noreply@<your-domain>` or
the actual hostname of the WAS server.

**`530 5.7.1 Authentication required`**
Relay does require auth. Either: (a) get a network/source-IP exception
from your messaging team, or (b) use the v1 solution with stored credentials.

**Snapshot dir keeps growing despite `RETENTION_COUNT`**
Confirm `drift.conf` is being read — check `ls -la $DRIFT_CONF` and look
for `Loaded config` in the run log. Env vars override file values, so
`unset RETENTION_COUNT` if it was set in your shell.

**Diff shows changes every single run with no admin activity**
A volatile field is leaking through inline normalization in
`extractConfig.py`. Capture two back-to-back snapshot diffs with no
admin changes, identify the noisy field, add a regex to `VOLATILE_PATTERNS`
in `extractConfig.py`.

**Python complains about `MIMEMultipart` import on old AIX**
The fallback import path in `drift_engine.py` handles Python 2.4-style
package layouts. If even that fails, your system Python is older than
2.4 — install a newer Python or use the WAS-bundled Jython for the engine
too (it has compatible `email` modules).
