#!/usr/bin/env python
###############################################################################
# drift_engine.py
#
# WebSphere config drift detection - Git-free version with auth-free SMTP.
#
# Responsibilities:
#   1. Manage timestamped snapshot directories (current + historical)
#   2. Diff "current" against "previous" using filesystem walk + difflib
#   3. Retain the last N snapshots (configurable), prune older ones
#   4. Send alert email via local/internal SMTP relay (no auth)
#
# Runs on the WAS host AFTER extractConfig.py has populated the new snapshot.
# Compatible with Python 2.6 / 2.7 (typical on RHEL 6/7 and AIX with WAS 8.5).
#
# Usage:
#   python drift_engine.py <snapshots_root> [--config drift.conf]
#
# Where <snapshots_root> contains:
#   <root>/current/                 <- just-extracted snapshot (input)
#   <root>/history/snapshot_YYYYMMDD_HHMMSS/   <- archived snapshots
#
# After a successful run:
#   - <current> is moved to <history>/snapshot_<ts>/
#   - Diff vs the prior history entry is computed
#   - If non-empty: email is sent
#   - Old snapshots beyond retention limit are deleted
###############################################################################

import os
import sys
import re
import time
import shutil
import difflib
import smtplib
import socket
import traceback

# Email - try modern import first, fall back for Python 2.6
try:
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from email.mime.base import MIMEBase
    from email import encoders
except ImportError:
    from email.MIMEText import MIMEText
    from email.MIMEMultipart import MIMEMultipart
    from email.MIMEBase import MIMEBase
    from email import Encoders as encoders


# =============================================================================
# Configuration - override via environment variables or a simple key=value file
# =============================================================================
DEFAULTS = {
    'SMTP_HOST':       'localhost',     # local postfix/sendmail relay
    'SMTP_PORT':       '25',
    'SMTP_TIMEOUT':    '30',            # seconds
    'SMTP_USE_TLS':    'false',         # 'true' to use STARTTLS (still no auth)
    'MAIL_FROM':       'was-drift@localhost',
    'MAIL_TO':         'was-admins@example.com',  # comma-separated for multiple
    'MAIL_SUBJECT_TAG': '[WAS DRIFT]',
    'RETENTION_COUNT': '30',            # how many historical snapshots to keep
    'MAX_DIFF_BYTES':  '500000',        # cap email size (~500KB of diff)
    'HOSTNAME':        socket.gethostname(),
}


def loadConfig(configPath):
    """Load config from env vars, then optionally from a key=value file."""
    cfg = {}
    for k, v in DEFAULTS.items():
        cfg[k] = os.environ.get(k, v)
    if configPath and os.path.exists(configPath):
        f = open(configPath, 'r')
        try:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '=' in line:
                    k, v = line.split('=', 1)
                    cfg[k.strip()] = v.strip()
        finally:
            f.close()
    return cfg


# =============================================================================
# Logging
# =============================================================================
def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    print("[%s] %s" % (ts, msg))


# =============================================================================
# Snapshot management
# =============================================================================
def listHistory(historyDir):
    """Return sorted list of snapshot_* dirs (oldest first)."""
    if not os.path.isdir(historyDir):
        return []
    entries = []
    for name in os.listdir(historyDir):
        full = os.path.join(historyDir, name)
        if os.path.isdir(full) and name.startswith('snapshot_'):
            entries.append(name)
    entries.sort()  # lexicographic == chronological for snapshot_YYYYMMDD_HHMMSS
    return entries


def archiveCurrent(snapshotsRoot):
    """
    Move <root>/current to <root>/history/snapshot_<timestamp>/.
    Returns the new history directory path, or None if nothing to archive.
    """
    currentDir = os.path.join(snapshotsRoot, 'current')
    historyDir = os.path.join(snapshotsRoot, 'history')

    if not os.path.isdir(currentDir):
        log("ERROR: %s does not exist - did extractConfig.py run?" % currentDir)
        return None

    # Verify the current dir actually has content
    hasContent = False
    for dirpath, dirnames, filenames in os.walk(currentDir):
        for fn in filenames:
            if fn.endswith('.props'):
                hasContent = True
                break
        if hasContent:
            break
    if not hasContent:
        log("ERROR: %s contains no .props files - extraction may have failed" % currentDir)
        return None

    if not os.path.isdir(historyDir):
        os.makedirs(historyDir)

    ts = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    target = os.path.join(historyDir, 'snapshot_' + ts)

    # Avoid collision if run twice in same second
    suffix = 0
    while os.path.exists(target):
        suffix = suffix + 1
        target = os.path.join(historyDir, 'snapshot_%s_%d' % (ts, suffix))

    shutil.move(currentDir, target)
    log("Archived current snapshot to %s" % target)
    return target


def pruneHistory(snapshotsRoot, retentionCount):
    """Delete snapshots beyond the retention count (oldest first)."""
    historyDir = os.path.join(snapshotsRoot, 'history')
    snapshots = listHistory(historyDir)
    excess = len(snapshots) - retentionCount
    if excess <= 0:
        return 0
    deleted = 0
    for name in snapshots[:excess]:
        path = os.path.join(historyDir, name)
        try:
            shutil.rmtree(path)
            log("Pruned old snapshot: %s" % name)
            deleted = deleted + 1
        except Exception:
            e = sys.exc_info()[1]
            log("WARN: failed to prune %s: %s" % (name, str(e)))
    return deleted


# =============================================================================
# Diff engine
# =============================================================================
def collectFiles(rootDir):
    """
    Walk rootDir and return dict { relative_path: absolute_path } for all
    .props files. Relative paths are POSIX-style for stable diff headers.
    """
    found = {}
    rootLen = len(rootDir.rstrip(os.sep)) + 1
    for dirpath, dirnames, filenames in os.walk(rootDir):
        for fn in filenames:
            if not fn.endswith('.props'):
                continue
            full = os.path.join(dirpath, fn)
            rel = full[rootLen:].replace(os.sep, '/')
            found[rel] = full
    return found


def readLines(path):
    f = open(path, 'rb')
    try:
        raw = f.read()
    finally:
        f.close()
    if isinstance(raw, bytes):
        text = raw.decode('latin-1')
    else:
        text = raw
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    # keepends=True so difflib output looks like a real unified diff
    return text.splitlines(True)


def computeDiff(oldDir, newDir):
    """
    Compare two snapshot directories. Returns (summary, fullDiff):
      summary: list of (status, relpath) tuples where status in
               'ADDED', 'REMOVED', 'MODIFIED'
      fullDiff: unified diff text covering all changed files
    """
    if oldDir is None:
        # First-ever snapshot - everything is "new" but we don't alert
        return ([], '')

    oldFiles = collectFiles(oldDir)
    newFiles = collectFiles(newDir)

    oldSet = set(oldFiles.keys())
    newSet = set(newFiles.keys())

    added    = sorted(newSet - oldSet)
    removed  = sorted(oldSet - newSet)
    common   = sorted(oldSet & newSet)

    summary = []
    diffParts = []

    for rel in added:
        summary.append(('ADDED', rel))
        newLines = readLines(newFiles[rel])
        d = difflib.unified_diff([], newLines,
                                 fromfile='(absent)',
                                 tofile='current/' + rel,
                                 lineterm='')
        diffParts.append('\n'.join(list(d)))

    for rel in removed:
        summary.append(('REMOVED', rel))
        oldLines = readLines(oldFiles[rel])
        d = difflib.unified_diff(oldLines, [],
                                 fromfile='previous/' + rel,
                                 tofile='(absent)',
                                 lineterm='')
        diffParts.append('\n'.join(list(d)))

    for rel in common:
        oldLines = readLines(oldFiles[rel])
        newLines = readLines(newFiles[rel])
        if oldLines == newLines:
            continue
        summary.append(('MODIFIED', rel))
        d = difflib.unified_diff(oldLines, newLines,
                                 fromfile='previous/' + rel,
                                 tofile='current/' + rel,
                                 lineterm='')
        diffParts.append('\n'.join(list(d)))

    fullDiff = '\n\n'.join(diffParts)
    return (summary, fullDiff)


def formatSummary(summary):
    """Human-readable summary block for the email body."""
    if not summary:
        return "(no changes)"
    counts = {'ADDED': 0, 'REMOVED': 0, 'MODIFIED': 0}
    lines = []
    for status, rel in summary:
        counts[status] = counts[status] + 1
        lines.append("  %-9s %s" % (status, rel))
    header = "Total: %d added, %d removed, %d modified\n" % (
        counts['ADDED'], counts['REMOVED'], counts['MODIFIED'])
    return header + '\n'.join(lines)


# =============================================================================
# Email (no auth, local/internal relay)
# =============================================================================
def sendAlert(cfg, subject, bodyText, diffText):
    """
    Send an alert email via unauthenticated SMTP relay.

    Strategy:
      - Connect to SMTP_HOST:SMTP_PORT
      - Optionally STARTTLS (some internal relays require encryption but no auth)
      - Do NOT call smtp.login() - relay must accept based on source IP / network ACL
      - Attach diff as a .txt attachment so email clients don't munge it
    """
    smtpHost   = cfg['SMTP_HOST']
    smtpPort   = int(cfg['SMTP_PORT'])
    timeout    = int(cfg['SMTP_TIMEOUT'])
    useTls     = cfg['SMTP_USE_TLS'].lower() == 'true'
    mailFrom   = cfg['MAIL_FROM']
    mailToRaw  = cfg['MAIL_TO']
    mailToList = [a.strip() for a in mailToRaw.split(',') if a.strip()]

    msg = MIMEMultipart()
    msg['From']    = mailFrom
    msg['To']      = ', '.join(mailToList)
    msg['Subject'] = subject

    msg.attach(MIMEText(bodyText, 'plain'))

    # Attach the full diff as a file (avoids body-size limits in many relays)
    if diffText:
        attach = MIMEBase('text', 'plain')
        # Truncate if oversized
        maxBytes = int(cfg['MAX_DIFF_BYTES'])
        diffBytes = diffText.encode('latin-1', 'replace')
        if len(diffBytes) > maxBytes:
            diffBytes = diffBytes[:maxBytes] + \
                ('\n\n--- DIFF TRUNCATED AT %d BYTES ---\n' % maxBytes).encode('latin-1')
        attach.set_payload(diffBytes)
        encoders.encode_base64(attach)
        attach.add_header('Content-Disposition',
                          'attachment; filename="drift.diff"')
        msg.attach(attach)

    log("Connecting to SMTP relay %s:%d (TLS=%s, no auth)" %
        (smtpHost, smtpPort, useTls))
    smtp = smtplib.SMTP(smtpHost, smtpPort, timeout=timeout)
    try:
        smtp.ehlo()
        if useTls:
            smtp.starttls()
            smtp.ehlo()
        # NOTE: no smtp.login() call - relying on relay's IP-based ACL
        smtp.sendmail(mailFrom, mailToList, msg.as_string())
        log("Email sent to: %s" % ', '.join(mailToList))
    finally:
        try:
            smtp.quit()
        except Exception:
            pass


# =============================================================================
# Main
# =============================================================================
def main(argv):
    if len(argv) < 2:
        print("Usage: python drift_engine.py <snapshots_root> [--config drift.conf]")
        return 1

    snapshotsRoot = argv[1]
    configPath = None
    if len(argv) >= 4 and argv[2] == '--config':
        configPath = argv[3]

    if not os.path.isdir(snapshotsRoot):
        log("ERROR: snapshots root does not exist: %s" % snapshotsRoot)
        return 1

    cfg = loadConfig(configPath)
    log("Drift engine starting on host %s" % cfg['HOSTNAME'])

    # Determine previous snapshot BEFORE archiving the new one
    historyDir = os.path.join(snapshotsRoot, 'history')
    priorSnapshots = listHistory(historyDir)
    previousDir = None
    if priorSnapshots:
        previousDir = os.path.join(historyDir, priorSnapshots[-1])
        log("Previous snapshot: %s" % priorSnapshots[-1])
    else:
        log("No previous snapshot - this run will establish the baseline")

    # Archive the just-extracted "current" into history
    newSnapshotDir = archiveCurrent(snapshotsRoot)
    if newSnapshotDir is None:
        return 2

    # Diff
    summary, fullDiff = computeDiff(previousDir, newSnapshotDir)

    if previousDir is None:
        log("Baseline established. No alert sent on first run.")
        pruneHistory(snapshotsRoot, int(cfg['RETENTION_COUNT']))
        return 0

    if not summary:
        log("No drift detected.")
        pruneHistory(snapshotsRoot, int(cfg['RETENTION_COUNT']))
        return 0

    log("DRIFT DETECTED: %d file(s) changed" % len(summary))

    # Build alert email
    summaryText = formatSummary(summary)
    runTs = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    subject = "%s Config change on %s at %s" % (
        cfg['MAIL_SUBJECT_TAG'], cfg['HOSTNAME'], runTs)

    body = """WebSphere configuration drift detected.

Host:         %s
Time:         %s
Snapshot:     %s
Previous:     %s
Snapshots dir: %s

Summary of changes:
%s

Full unified diff is attached as drift.diff.
""" % (cfg['HOSTNAME'], runTs, os.path.basename(newSnapshotDir),
       os.path.basename(previousDir), snapshotsRoot, summaryText)

    # Also write the diff to disk for local audit even if email fails
    diffOnDisk = os.path.join(snapshotsRoot, 'last_drift.diff')
    f = open(diffOnDisk, 'wb')
    try:
        f.write(fullDiff.encode('latin-1', 'replace'))
    finally:
        f.close()
    log("Diff written to %s" % diffOnDisk)

    # Send email
    try:
        sendAlert(cfg, subject, body, fullDiff)
    except Exception:
        log("ERROR sending alert email:")
        log(traceback.format_exc())
        # Don't fail the whole run - we still have the diff on disk
        pruneHistory(snapshotsRoot, int(cfg['RETENTION_COUNT']))
        return 3

    pruneHistory(snapshotsRoot, int(cfg['RETENTION_COUNT']))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
